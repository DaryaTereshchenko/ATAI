import re
from speakeasypy import Chatroom, EventType, Speakeasy
try:
    from sanitizer import sanitize_query
except Exception:
    def sanitize_query(q: str) -> str:
        return q
try:
    from rdf import RDFStore
except Exception:
    RDFStore = None

DEFAULT_HOST_URL = 'https://speakeasy.ifi.uzh.ch'


class Agent:

    def __init__(self, username: str, password: str) -> None:
        self.username = username
        self.speakeasy = Speakeasy(
            host=DEFAULT_HOST_URL, username=username, password=password
        )
        self.speakeasy.login()
        self.store = None
        if RDFStore is not None:
            try:
                self.store = RDFStore()
                print("[bot] RDF store initialised.")
            except Exception as e:
                print(f"[bot] RDF store disabled (error): {e}")
        self.speakeasy.register_callback(self.on_new_message, EventType.MESSAGE)
        self.speakeasy.register_callback(self.on_new_reaction, EventType.REACTION)

    def listen(self) -> None:
        self.speakeasy.start_listening()

    @staticmethod
    def _stringify_results(results):
        if not results:
            return "[]"
        lines = []
        for i, row in enumerate(results):
            if i >= 200:
                lines.append("... (truncated after 200 rows)")
                break
            if isinstance(row, (list, tuple)):
                lines.append(" | ".join(map(str, row)))
            else:
                lines.append(str(row))
        return "\n".join(lines)

    def on_new_message(self, message: str, room: Chatroom) -> None:
        try:
            print(f"[bot] Raw message: {message!r}")
            print(f"[bot] Message type: {type(message)}, length: {len(message) if message else 0}")

            # Reject empty or whitespace-only messages
            if not message or not str(message).strip():
                print("[bot] Received empty or None message.")
                room.post_messages("No query received. Please enter a valid query.")
                return

            if self.store is None:
                print("[bot] RDF store disabled; echoing")
                room.post_messages(f"You said: '{message}'. How can I assist further?")
                return

            message = message.strip()
            graph_iri = None
            iri_match = re.match(r"^<([^>]+)>", message)
            if iri_match:
                graph_iri = iri_match.group(1)
                message = re.sub(r"^<[^>]+>\s*", "", message)
                print(f"[bot] Detected graph IRI header: {graph_iri} (ignored for .nt default graph)")

            required_prefixes = {
                "wd": "http://www.wikidata.org/entity/",
                "wdt": "http://www.wikidata.org/prop/direct/",
                "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
                "schema": "http://schema.org/",
                "ddis": "http://ddis.ch/atai/",
            }
            prefix_lines = []
            for k, iri in required_prefixes.items():
                uses = re.search(rf"(?<![\w:]){re.escape(k)}:", message) is not None
                has_decl = re.search(rf"(?i)\bPREFIX\s+{re.escape(k)}\s*:", message) is not None
                if uses and not has_decl:
                    prefix_lines.append(f"PREFIX {k}: <{iri}>")
            if prefix_lines:
                message = "\n".join(prefix_lines) + "\n" + message

            # Run through the sanitizer to normalise prefixes / wrap WHERE if needed
            safe_message = sanitize_query(message)
            print(f"[bot] Sanitized message:\n{safe_message}")

            # Base query
            query = safe_message
            print("[bot] FINAL QUERY (before run):\n" + query)

            # Execute the query
            try:
                results = self.store.run_query(query)
            except Exception as e:
                print(f"[bot] Query execution error: {e}")
                room.post_messages(f"Query execution error: {e}")
                return

            print(f"[bot] Results (main): {len(results) if results else 0}")

            # --------- Fallback 1: broaden wdt:P57 to (wdt:P57|schema:director) ----------
            if (not results) and ("wdt:P57" in query or " P57 " in message or "(P57" in message):
                # Ensure we target the sanitized form if present
                broaden_target = "wdt:P57" if "wdt:P57" in query else "P57"
                print("[bot] Attempting director property fallback")
                alt_q = re.sub(
                    rf"(?<!\()(?<!\|)\b{re.escape(broaden_target)}\b(?![?*+])",
                    "(wdt:P57|schema:director)",
                    query
                )
                print("[bot] Fallback alternative query:\n" + alt_q)
                try:
                    tmp = self.store.run_query(alt_q)
                    print(f"[bot] Fallback results: {len(tmp) if tmp else 0}")
                    if tmp:
                        results = tmp
                        query = alt_q
                except Exception as e:
                    print("[bot] Fallback error:", e)
            if not results:
                m = re.search(r'rdfs:label\s+"([^"]+)"\s*@?[a-zA-Z-]*', query)
                if m:
                    title = m.group(1)
                    print(f"[bot] Relaxing exact label match for title: {title!r}")

                    title_lower = title.lower()
                    title_lower_esc = title_lower.replace('"', '\\"')

                    relaxed = re.sub(
                        r'rdfs:label\s+"[^"]+"\s*@?[a-zA-Z-]*\s*\.',
                        'rdfs:label ?lbl .',
                        query
                    )

                    if "CONTAINS(LCASE(STR(?lbl))" not in relaxed:
                        needle = r'(rdfs:label\s+\?lbl\s*\.\s*)'
                        relaxed = re.sub(
                            needle,
                            r'\g<1>FILTER(CONTAINS(LCASE(STR(?lbl)), "' + title_lower_esc + r'")) . ',
                            relaxed,
                            count=1
                        )

                    print("[bot] Attempting relaxed-label fallback:\n" + relaxed)
                    try:
                        tmp2 = self.store.run_query(relaxed)
                        print(f"[bot] Relaxed-label fallback results: {len(tmp2) if tmp2 else 0}")
                        if tmp2:
                            results = tmp2
                            query = relaxed
                    except Exception as e:
                        print("[bot] Relaxed-label fallback error:", e)

            if not results:
                m2 = re.search(r'rdfs:label\s+"([^"]+)"', message) or re.search(r'rdfs:label\s+"([^"]+)"', query)
                if m2:
                    title2 = m2.group(1)
                    print(f"[bot] Attempting QID resolve for title: {title2!r}")
                    title2_lower = title2.lower()
                    title2_lower_esc = title2_lower.replace('"', '\\"')

                    resolver = (
                        "PREFIX wdt:<http://www.wikidata.org/prop/direct/> "
                        "PREFIX wd:<http://www.wikidata.org/entity/> "
                        "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> "
                        "SELECT ?movie WHERE { "
                        "  ?movie wdt:P31 wd:Q11424 ; rdfs:label ?lbl . "
                        f'  FILTER(CONTAINS(LCASE(STR(?lbl)), "{title2_lower_esc}")) '
                        "} LIMIT 1"
                    )
                    try:
                        ids = self.store.run_query(resolver)
                        print(f"[bot] Resolver rows: {ids}")
                        movie_uri = None
                        if ids:
                            first = ids[0]
                            if isinstance(first, list) and first:
                                movie_uri = first[0]
                            elif isinstance(first, str):
                                movie_uri = first
                        if movie_uri and "/entity/" in str(movie_uri):
                            qid = str(movie_uri).split("/entity/")[-1]
                            # Build a final query that binds the Q-ID and unions director properties
                            final_q = (
                                "PREFIX wd:<http://www.wikidata.org/entity/> "
                                "PREFIX wdt:<http://www.wikidata.org/prop/direct/> "
                                "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> "
                                "PREFIX schema:<http://schema.org/> "
                                "SELECT ?director WHERE { "
                                f"  BIND(wd:{qid} AS ?movie) "
                                "  ?movie (wdt:P57 | schema:director) ?d . "
                                "  ?d rdfs:label ?director . "
                                "} LIMIT 10"
                            )
                            print("[bot] Attempting QID-bound fallback:\n" + final_q)
                            tmp3 = self.store.run_query(final_q)
                            print(f"[bot] QID-bound fallback results: {len(tmp3) if tmp3 else 0}")
                            if tmp3:
                                results = tmp3
                                query = final_q
                    except Exception as e:
                        print("[bot] QID-bound fallback error:", e)

            if results:
                print("[bot] Posting results with query:\n" + query)
                room.post_messages(self._stringify_results(results))
            else:
                print("[bot] No results found for your query.")
                room.post_messages(
                    "No results found for your query. Please check your query or try a different one."
                )

        except Exception as exc:
            print(f"[bot] TOP-LEVEL EXCEPTION: {exc}")
            try:
                room.post_messages(f"An error occurred while processing your query: {exc}")
            except Exception as e:
                print(f"[bot] Failed to send error message: {e}")

    def on_new_reaction(self, reaction: str, message_ordinal: int, room: Chatroom) -> None:
        """Acknowledge reactions to messages."""
        print(f"New reaction '{reaction}' on message #{message_ordinal} in room {room.room_id}")
        try:
            room.post_messages(f"Thanks for your reaction: '{reaction}'")
        except Exception as e:
            print(f"[bot] Failed to post reaction ack: {e}")


if __name__ == "__main__":
    my_bot = Agent("BeigeCrackingEgg", "Vb2Xv8iY")
    my_bot.listen()


