# sanitizer.py
import re
from typing import Dict

PREFIXES: Dict[str, str] = {
    "wd": "http://www.wikidata.org/entity/",
    "wdt": "http://www.wikidata.org/prop/direct/",
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "schema": "http://schema.org/",
    "ddis": "http://ddis.ch/atai/",
}

def _strip_leading_iris(q: str) -> str:
    q = (q or "").strip()
    while True:
        new_q = re.sub(r"^\s*<https?://[^>]+>\s*", "", q)
        if new_q == q:
            break
        q = new_q.strip()
    q = re.sub(r"^\s*[.;,]+\s*", "", q)
    return q

def _rewrite_bare_ids(q: str) -> str:
    parts = re.split(r"(<[^>]*>)", q)
    for i, part in enumerate(parts):
        if part.startswith("<") and part.endswith(">"):
            continue
        part = re.sub(r"(?<![\w:])P(\d+)(?![\w:])", r"wdt:P\1", part)
        part = re.sub(r"(?<![\w:])Q(\d+)(?![\w:])", r"wd:Q\1", part)
        parts[i] = part
    return "".join(parts)

def _ensure_prefixes(q: str) -> str:
    missing = []
    for k, iri in PREFIXES.items():
        uses = re.search(rf"(?<![\w:]){re.escape(k)}:", q) is not None
        has_decl = re.search(rf"(?i)\bPREFIX\s+{re.escape(k)}\s*:", q) is not None
        if uses and not has_decl:
            missing.append(f"PREFIX {k}: <{iri}>")
    if missing:
        q = "\n".join(missing) + "\n" + q
    seen = set()
    out_lines = []
    rx = re.compile(r"(?i)^\s*PREFIX\s+([A-Za-z][\w-]*)\s*:\s*<[^>]+>\s*$")
    for line in q.splitlines():
        m = rx.match(line)
        if m:
            prefix_name = m.group(1).lower()
            if prefix_name in seen:
                continue
            seen.add(prefix_name)
        out_lines.append(line)
    return "\n".join(out_lines)

def _separate_prefixes(q: str) -> str:
    lines = q.splitlines()
    new_lines = []
    for line in lines:
        stripped = line.lstrip()
        if stripped.upper().startswith("PREFIX"):
            parts = re.split(r"(?i)\bPREFIX\b", stripped)
            leading_ws = line[: len(line) - len(stripped)]
            for part in parts:
                if not part:
                    continue
                entry = ("PREFIX " + part.strip()).rstrip()
                new_lines.append(leading_ws + entry)
        else:
            new_lines.append(line)
    return "\n".join(new_lines)

def _wrap_patterns_if_needed(q: str) -> str:
    qs = q.strip()
    if re.search(r"(?is)\bselect\b.+\bwhere\s*\{", qs):
        return qs
    m = re.search(r"(?is)\b(select\b.+?\bwhere\b)(.*)$", qs)
    if m and "{" not in qs:
        head = m.group(1).strip()
        body = m.group(2).strip()
        tail = ""
        mt = re.search(r"(?is)\b(order\s+by|limit|offset)\b.*$", body)
        if mt:
            tail = body[mt.start():]
            body = body[: mt.start()].strip()
        return f"{head} {{ {body} }} {tail}".strip()
    has_var_or_iri = re.search(r"[?$][A-Za-z_]\w*|<https?://", qs) is not None
    has_pred = re.search(r"\b[a-zA-Z][\w-]*:\w+|<[^>]+>", qs) is not None
    if has_var_or_iri and has_pred:
        return f"SELECT * WHERE {{\n{qs}\n}}"
    return qs

def sanitize_query(q: str) -> str:
    q = _rewrite_bare_ids(q)
    q = _ensure_prefixes(q)
    q = _separate_prefixes(q)
    q = _wrap_patterns_if_needed(q)
    q = _rewrite_bare_ids(q)
    return q
