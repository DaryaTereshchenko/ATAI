import sys
import os
import re
from typing import List, Tuple, Optional, Dict, Set
from collections import defaultdict
import csv

# === Add project root for imports ===
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from src.main.recommender.vector_index import MovieVectorIndex

def _quick_grep_directors(graph_path: str, director_name: str):
    """Ultra-fast scan for directors in the .nt KG file (no full parse)."""
    director_prop = "http://www.wikidata.org/prop/direct/P57"
    label_prop = "http://www.w3.org/2000/01/rdf-schema#label"

    def _norm(s: str) -> str:
        s = s.lower()
        s = re.sub(r"\s*\(.*?\)\s*", "", s)
        s = re.sub(r"^(the|a|an)\s+", "", s)
        s = re.sub(r"[^a-z0-9 ]+", " ", s)
        return re.sub(r"\s+", " ", s).strip()

    director_norm = _norm(director_name)
    director_uris: Set[str] = set()

    # Find URIs for this director
    with open(graph_path, 'r', encoding='utf-8') as f:
        for line in f:
            if label_prop in line:
                parts = line.split()
                if len(parts) >= 3:
                    uri = parts[0].strip('<>')
                    label = ' '.join(parts[2:])
                    label = re.sub(r'"(.*?)".*', r'\1', label)
                    if len(set(_norm(label).split()) & set(director_norm.split())) >= 2:
                        director_uris.add(uri)

    if not director_uris:
        return []

    movie_uris: Set[str] = set()
    with open(graph_path, 'r', encoding='utf-8') as f:
        for line in f:
            if director_prop in line:
                for dir_uri in director_uris:
                    if dir_uri in line:
                        parts = line.split()
                        if parts:
                            movie_uris.add(parts[0].strip('<>'))

    movie_labels: Dict[str, str] = {}
    with open(graph_path, 'r', encoding='utf-8') as f:
        for line in f:
            if label_prop in line:
                for mu in movie_uris:
                    if mu in line and '@en' in line:
                        parts = line.split()
                        if len(parts) >= 3:
                            label = ' '.join(parts[2:])
                            label = re.sub(r'"(.*?)".*', r'\1', label)
                            movie_labels[mu] = label

    return list(movie_labels.values())


def ultra_fast_director_query(query: str) -> Optional[str]:
    q = query.lower().strip()
    m = re.search(r'top\s+(\d+)\s+(?:rated\s+)?(?:movies|films)\s+by\s+(.+?)(?:\?|$)', q)
    if not m:
        return None

    topn = int(m.group(1))
    director = m.group(2).strip()

    print(f"\n⚡ FAST PATH activated for: {director}")
    graph_path = os.environ.get("ATAI_KG_PATH") or os.environ.get("GRAPH_FILE_PATH")
    movielens_dir = os.environ.get("MOVIELENS_DIR") or "data"

    if not graph_path or not os.path.exists(graph_path):
        return None

    director_movies = _quick_grep_directors(graph_path, director)
    if not director_movies:
        return None

    movies_path = os.path.join(movielens_dir, "movies.csv")
    ratings_path = os.path.join(movielens_dir, "ratings.csv")
    if not os.path.exists(movies_path) or not os.path.exists(ratings_path):
        return None

    ml_movies = {}
    with open(movies_path, 'r', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            ml_movies[int(row['movieId'])] = row.get('title', '').strip()

    ratings_data = defaultdict(lambda: {'sum': 0.0, 'count': 0})
    with open(ratings_path, 'r', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            mid = int(row['movieId'])
            ratings_data[mid]['sum'] += float(row['rating'])
            ratings_data[mid]['count'] += 1

    matched = []
    for mov in director_movies:
        mov_norm = re.sub(r'\s*\(.*?\)|\W+', ' ', mov).lower().strip()
        for mid, ml_title in ml_movies.items():
            ml_norm = re.sub(r'\s*\(.*?\)|\W+', ' ', ml_title).lower().strip()
            if mov_norm in ml_norm or ml_norm in mov_norm or len(set(mov_norm.split()) & set(ml_norm.split())) >= 2:
                d = ratings_data[mid]
                if d['count'] >= 5:
                    matched.append((ml_title, d['sum'] / d['count'], d['count']))
                break

    if not matched:
        return None

    matched.sort(key=lambda x: (-x[1], x[0]))
    matched = matched[:topn]

    lines = [f"🎬 **Top {len(matched)} rated movies by {director.title()}**", ""]
    for i, (title, rating, count) in enumerate(matched, 1):
        lines.append(f"{i}. {title}")
        lines.append(f" **{rating:.2f}/5.0** ({count:,} ratings)")
        if i < len(matched):
            lines.append("")
    return "\n".join(lines)

_idx: MovieVectorIndex = None

def _get_index() -> MovieVectorIndex:
    global _idx
    if _idx is None:
        _idx = MovieVectorIndex(10000)
    return _idx

def _format(rows: List[Tuple[str, float]], idx: MovieVectorIndex) -> str:
    if not rows:
        return (" **Error**\n\n"
                "Sorry, I encountered an error processing your request.\n\n"
                "Details: no recommendations found.\n")
    lines = [" **Recommendations**", ""]
    for title, _score in rows:
        avg = idx.rating.get(title, 0.0)
        lines.append(f"- {title}, Avg {avg:.2f}")
    return "\n".join(lines)


class Orchestrator:
  

    def _looks_like_recommendation(self, q: str) -> bool:
        ql = (q or "").lower()
        if any(k in ql for k in ["recommend", "suggest", "like ", "similar"]):
            return True
        if any(k in ql for k in ["oscar", "academy award", "best picture", "golden globe"]):
            return True
        if any(k in ql for k in ["written by", "screenwriter", "directed by", "movies by", "films by"]):
            return True
        if any(k in ql for k in ["highest rated", "top rated"]) or re.search(r"\btop\s+\d+\b", ql):
            return True
        if any(g in ql for g in ["horror", "animation", "drama", "comedy", "romance", "thriller", "sci-fi", "family"]):
            return True
        return False

    def process_query(self, query: str) -> str:
        if not query:
            return "Please provide a movie-related query."

        # Fast director path
        fast_answer = ultra_fast_director_query(query)
        if fast_answer:
            return fast_answer

        idx = _get_index()
        m = re.search(r"\btop\s+(\d+)\b", query.lower())
        topn = int(m.group(1)) if m else 5

        try:
            if self._looks_like_recommendation(query):
                rows = idx.query(query, topn=topn)
                return _format(rows, idx)
            # fallback still returns recommendations
            rows = idx.query(query, topn=topn)
            return _format(rows, idx)
        except Exception as e:
            return (f" **Error**\n\n"
                    f"Sorry, I encountered an error processing your request.\n\n"
                    f"Details: {e}\n")

if __name__ == "__main__":
    orch = Orchestrator()
    q = sys.argv[1] if len(sys.argv) > 1 else "films written by Charlie Kaufman"
    print(orch.process_query(q))
