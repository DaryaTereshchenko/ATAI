# recommendation_workflow.py — Vector Similarity First → KG Fallback (hardened)
import os
import traceback
from typing import List, Dict, Optional

# Try both local + packaged imports
try:
    from src.main.recommender.engine import KGFeatureStore
    from src.main.recommender.runtime import recommend_from_text as _core_recommend
except Exception:
    try:
        from engine import KGFeatureStore  # type: ignore
        from runtime import recommend_from_text as _core_recommend  # type: ignore
    except Exception:
        KGFeatureStore = None  # type: ignore
        _core_recommend = None  # type: ignore

try:
    from src.main.recommender.vector_index import MovieVectorIndex
except Exception:
    # Fallback to local module
    from src.main.recommender.vector_index import MovieVectorIndex


# SINGLETON index (constructed once in the process)
_VECTOR_INDEX = MovieVectorIndex()

def _ensure_paths(kg_path: Optional[str]):
    # Accept both a directory OR a file path for graph.nt
    if kg_path:
        # If directory, set both envs to it; if a file, set envs to its parent dir
        if os.path.isdir(kg_path):
            os.environ.setdefault("ATAI_KG_PATH", kg_path)
            os.environ.setdefault("GRAPH_FILE_PATH", kg_path)
        else:
            parent = os.path.dirname(kg_path)
            if parent:
                os.environ.setdefault("ATAI_KG_PATH", parent)
                os.environ.setdefault("GRAPH_FILE_PATH", parent)

    # If MOVIELENS_DIR isn’t set, try to find the files locally
    if os.environ.get("MOVIELENS_DIR"):
        return

    for d in ["data", ".", os.getcwd(), "/mnt/data", "/mnt/user-data/uploads"]:
        if (os.path.isfile(os.path.join(d, "movies.csv"))
            and os.path.isfile(os.path.join(d, "ratings.csv"))):
            os.environ.setdefault("MOVIELENS_DIR", d)
            break


def _detect_genre(text: str) -> Optional[str]:
    genres = ["drama","horror","comedy","romance","thriller","animation","crime",
              "fantasy","action","adventure","family","mystery","war","western",
              "musical","biography","sci-fi","science fiction","documentary"]
    t = (text or "").lower()
    for g in genres:
        if g in t:
            # normalize common alias
            if g in ("sci-fi", "science fiction"):
                return "sci-fi"
            return g
    return None


def recommend_from_text(text: str, user_id: str = "cli",
                        kg_path: Optional[str] = None, topn: int = 10) -> List[Dict]:
    """
    Main entrypoint used by the bot.
    ALWAYS returns a list (possibly empty). Never raises.
    Each item: {"uri": Optional[str], "label": str, "score": float}
    """
    try:
        _ensure_paths(kg_path)

        # 1) Vector index (fast path)
        genre = _detect_genre(text)
        vec_results = _VECTOR_INDEX.query(text, topn=max(topn, 20), genre=genre)

        # Keep only “useful” scores; tune the floor if needed
        vec_results = [(t, s) for (t, s) in vec_results if s is not None and float(s) >= 0.10]

        if vec_results:
            return [{"uri": None, "label": t, "score": float(s)} for (t, s) in vec_results[:topn]]

        # 2) Optional KG fallback (only if available)
        if _core_recommend is None:
            return []  # graceful no-KG environment

        results, seed_uris, unresolved = _core_recommend(text, topn=topn)

        # Try to resolve labels if we have a KGStore
        kg = None
        try:
            if KGFeatureStore:
                kg = KGFeatureStore(os.environ.get("ATAI_KG_PATH"))
        except Exception:
            kg = None

        out: List[Dict] = []

        if unresolved:
            out.append({"uri": None, "label": f"UNRESOLVED: {', '.join(unresolved)}", "score": 0.0})
        if seed_uris:
            out.append({"uri": None, "label": "SEEDS: " + ", ".join(seed_uris), "score": 0.0})

        for uri_or_title, score in results:
            label = uri_or_title
            uri = None
            if kg and isinstance(uri_or_title, str) and uri_or_title.startswith("http"):
                uri = uri_or_title
                try:
                    label = kg.label(uri_or_title) or uri_or_title
                except Exception:
                    pass
            elif kg:
                try:
                    lookup = kg.lookup_by_label(str(label))
                    if lookup:
                        uri = lookup
                except Exception:
                    pass
            out.append({"uri": uri, "label": str(label), "score": float(score)})

        return out

    except Exception as e:
        # NEVER bubble exceptions to the bot — return an empty list.
        # Also log a compact error so you can debug.
        print("recommend_from_text() ERROR:", str(e))
        traceback.print_exc()
        return []
