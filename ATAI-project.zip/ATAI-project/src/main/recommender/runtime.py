# runtime.py — robust NL → recommendations (fast, accurate, KG-cached)
from __future__ import annotations

import os
import re
import csv
from collections import defaultdict
from typing import List, Tuple, Dict, Optional, Set, Any

try:
    from .engine import KGFeatureStore, FeedbackStore, HybridRecommender  # type: ignore
except Exception:
    from engine import KGFeatureStore, FeedbackStore, HybridRecommender  # type: ignore

_MOVIELENS_AVG: Optional[Dict[str, float]] = None
_MOVIELENS_GENRES: Optional[Dict[str, List[str]]] = None

def _candidate_movielens_paths(movies_path: Optional[str], ratings_path: Optional[str]):
    env_dir = os.environ.get("MOVIELENS_DIR")
    cwd = os.getcwd()
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [
        (movies_path, ratings_path),
        (os.path.join(cwd, "movies.csv"), os.path.join(cwd, "ratings.csv")),
        (os.path.join(cwd, "data", "movies.csv"), os.path.join(cwd, "data", "ratings.csv")),
        (os.path.join(here, "movies.csv"), os.path.join(here, "ratings.csv")),
        (os.path.join(here, "..", "..", "data", "movies.csv"), os.path.join(here, "..", "..", "data", "ratings.csv")),
        ("/mnt/data/movies.csv", "/mnt/data/ratings.csv"),
    ]
    if env_dir:
        cands.insert(0, (os.path.join(env_dir, "movies.csv"), os.path.join(env_dir, "ratings.csv")))
    seen, out = set(), []
    for m, r in cands:
        key = (m or ""), (r or "")
        if key not in seen:
            out.append((m, r))
            seen.add(key)
    return out

def load_movielens(movies_path: Optional[str] = None, ratings_path: Optional[str] = None) -> Tuple[Dict[str, float], Dict[str, List[str]]]:
    global _MOVIELENS_AVG, _MOVIELENS_GENRES
    if _MOVIELENS_AVG is not None and _MOVIELENS_GENRES is not None:
        return _MOVIELENS_AVG, _MOVIELENS_GENRES
    for m, r in _candidate_movielens_paths(movies_path, ratings_path):
        if m and r and os.path.isfile(m) and os.path.isfile(r):
            movies_path, ratings_path = m, r
            break
    if not movies_path or not ratings_path or not os.path.isfile(movies_path) or not os.path.isfile(ratings_path):
        _MOVIELENS_AVG, _MOVIELENS_GENRES = {}, {}
        return _MOVIELENS_AVG, _MOVIELENS_GENRES

    movies: Dict[int, str] = {}
    genres_map: Dict[str, List[str]] = {}
    with open(movies_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                mid = int(row.get("movieId", ""))
            except Exception:
                continue
            title = (row.get("title") or "").strip()
            if not title:
                continue
            movies[mid] = title
            genres_map[title] = (row.get("genres") or "").split("|") if row.get("genres") else []
    ratings_acc: Dict[int, List[float]] = defaultdict(list)
    with open(ratings_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                mid = int(row.get("movieId", ""))
                rating = float(row.get("rating", ""))
            except Exception:
                continue
            ratings_acc[mid].append(rating)
    avg: Dict[str, float] = {}
    for mid, vals in ratings_acc.items():
        if vals and mid in movies:
            avg[movies[mid]] = sum(vals) / len(vals)
    _MOVIELENS_AVG, _MOVIELENS_GENRES = avg, genres_map
    return avg, genres_map

def _normalize_simple(s: str) -> str:
    s = s.lower()
    s = re.sub(r"\s*\(.*?\)\s*", "", s)
    s = re.sub(r"^(the|a|an)\s+", "", s)
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def _norm_strip(title: str) -> str:
    t = re.sub(r"\s*\(.*?\)\s*", "", title)
    t = re.sub(r"^(the|a|an)\s+", "", t, flags=re.I)
    t = re.sub(r"[^a-z0-9 ]+", " ", t, flags=re.I)
    return re.sub(r"\s+", " ", t).strip().lower()

def _smart_split_titles(text: str) -> List[str]:
    quoted = re.findall(r'"([^"]+)"|\'([^\']+)\'', text)
    if quoted:
        return [(a or b).strip() for a, b in quoted if (a or b).strip()]
    m = re.search(r"(?:given that i like|i like|like|similar to)\s+(.+?)(?:\?|$|,\s*can you|,\s*could you|,\s*please)", text, flags=re.I)
    if not m:
        return []
    tail = m.group(1).strip()
    parts = [p.strip() for p in tail.split(",") if p.strip()]
    out: List[str] = []
    for part in parts:
        part = re.sub(r"^\s*and\s+", "", part, flags=re.I).strip()
        if not part:
            continue
        if " and " in part.lower():
            first, *rest = re.split(r"\s+and\s+", part, flags=re.I)
            if rest and re.match(r"^(the|a|an)\s+\w", rest[0], flags=re.I):
                out.append(part)
            else:
                out.append(first.strip())
                out.extend(p.strip() for p in rest if p.strip())
        else:
            out.append(part)
    cleaned = []
    for t in out:
        t = re.sub(r"[?.!]+$", "", t)
        t = re.sub(r"\b(can you|could you|please|recommend|some|movies?|films?).*$", "", t, flags=re.I)
        t = t.strip()
        if t:
            cleaned.append(t)
    return cleaned

def _is_disney_context(titles: List[str]) -> bool:
    disney_keywords = [
        "lion king","pocahontas","beauty and the beast","aladdin","mulan",
        "cinderella","snow white","sleeping beauty","little mermaid","bambi",
        "dumbo","frozen","tangled","moana","hercules","tarzan","aristocats",
        "hunchback of notre dame","jungle book","peter pan","winnie the pooh",
        "pinocchio","alice in wonderland","101 dalmatians","fox and the hound",
        "great mouse detective","rescuers","black cauldron"
    ]
    count = sum(1 for t in titles if any(k in t.lower() for k in disney_keywords))
    return count >= max(1, len(titles) // 2)

def disney_candidates(avg: Dict[str, float], genres_map: Dict[str, List[str]], exclude: List[str], topn: int) -> List[Tuple[str, float]]:
    dkw = [
        "lion king","pocahontas","beauty and the beast","beauty & the beast","aladdin","mulan","cinderella","snow white",
        "sleeping beauty","little mermaid","bambi","dumbo","lady and the tramp","101 dalmatians","aristocats","robin hood",
        "fox and the hound","black cauldron","great mouse detective","the rescuers","tarzan","hercules","hunchback of notre dame",
        "jungle book","peter pan","winnie the pooh","frozen","tangled","moana","rapunzel","pinocchio","alice in wonderland",
        "snow white and the seven dwarfs","maleficent","cruella","pete's dragon"
    ]
    SHORTS = ["goes visiting","day of concern","honey tree","blustery day","tigger too","a day for eeyore","sing along","storybook","shorts","featurette"]
    FEATURE_REMAKES = {_normalize_simple(x) for x in [
        "Cinderella (2015)","Beauty and the Beast (2017)","Aladdin (2019)","The Lion King (2019)",
        "The Jungle Book (2016)","Maleficent (2014)","Cruella (2021)","Pete's Dragon (2016)","Dumbo (2019)"
    ]}
    ex = {_normalize_simple(x) for x in exclude}
    rows: List[Tuple[str, float, int]] = []
    for title, rating in avg.items():
        if _normalize_simple(title) in ex:
            continue
        lt = title.lower()
        genres = [g.lower() for g in genres_map.get(title, [])]
        if not (any(kw in lt for kw in dkw) and any(g in genres for g in ["animation","children","family","fantasy"])):
            continue
        if any(p in lt for p in SHORTS):
            continue
        boost = 1 if _normalize_simple(title) in FEATURE_REMAKES else 0
        rows.append((title, float(rating), boost))
    rows.sort(key=lambda x: (-x[2], -x[1], x[0]))
    return [(t, r) for (t, r, _b) in rows[:topn]]

def _find_best_match_in_kg(kg: KGFeatureStore, target_title: str) -> Optional[str]:
    target_norm = _normalize_simple(target_title)
    target_words = set(target_norm.split())
    if not target_words:
        return None
    best_uri = None
    best_score = 0.0
    candidate_iter = getattr(kg, "candidates_for_title", lambda _t: kg.all_movies())(target_title)
    for uri in candidate_iter:
        lbl = kg.label(uri) or ""
        kg_norm = _normalize_simple(lbl)
        if not kg_norm:
            continue
        words = set(kg_norm.split())
        if not words:
            continue
        inter = len(target_words & words)
        union = len(target_words | words)
        if not union:
            continue
        sim = inter / union
        bonus = 0.2 if (target_norm in kg_norm or kg_norm in target_norm) else 0.0
        score = sim + bonus
        if score >= 0.4 and score > best_score:
            if abs(len(target_norm) - len(kg_norm)) < 30:
                best_score = score
                best_uri = uri
    return best_uri

def _find_by_partial_word(kg: KGFeatureStore, target_title: str) -> Optional[str]:
    words = set(_normalize_simple(target_title).split())
    best_uri = None
    best_overlap = 0
    candidate_iter = getattr(kg, "candidates_for_title", lambda _t: kg.all_movies())(target_title)
    for uri in candidate_iter:
        lbl = kg.label(uri) or ""
        w = set(_normalize_simple(lbl).split())
        overlap = len(words & w)
        if overlap > best_overlap:
            best_overlap = overlap
            best_uri = uri
    return best_uri if best_overlap > 0 else None

def _best_title_match(kg: KGFeatureStore, avg: Dict[str, float], genres_map: Dict[str, List[str]], title: str, disney_context: bool) -> Optional[str]:
    if disney_context:
        dc = disney_candidates(avg, genres_map, [], 80)
        qn = _normalize_simple(title)
        for ml_title, _r in dc:
            if _normalize_simple(ml_title) == qn:
                u = _find_best_match_in_kg(kg, ml_title)
                if u:
                    return u
        q_words = set(qn.split())
        best_ml = None
        best_ml_sim = 0.0
        for ml_title, _r in dc:
            tw = set(_normalize_simple(ml_title).split())
            if not tw or not q_words:
                continue
            inter = len(q_words & tw)
            union = len(q_words | tw)
            sim = inter / union if union else 0.0
            if sim > 0.4 and sim > best_ml_sim:
                best_ml_sim = sim
                best_ml = ml_title
        if best_ml:
            u = _find_best_match_in_kg(kg, best_ml)
            if u:
                return u
        u = _find_best_match_in_kg(kg, title)
        if u:
            ll = (kg.label(u) or "").lower()
            disney_kw = ["lion king","pocahontas","beauty","aladdin","mulan","cinderella","snow white","mermaid","sleeping beauty","dalmatian","aristocats","jungle book","maleficent","cruella","pete"]
            if any(k in ll for k in disney_kw):
                return u
        u = _find_by_partial_word(kg, title)
        if u:
            lab = kg.label(u) or ""
            if len(lab.strip()) > 2:
                return u
        return None
    u = _find_best_match_in_kg(kg, title)
    if u:
        return u
    return kg.lookup_by_label(title)

_MAP_CACHE: Dict[str, Optional[str]] = {}
def _safe_map_title_to_kg(kg: KGFeatureStore, title: str) -> Optional[str]:
    key = _normalize_simple(title)
    if key in _MAP_CACHE:
        return _MAP_CACHE[key]
    base = re.sub(r"\s*\(\d{4}\)\s*$", "", title).strip()
    tnorm = _normalize_simple(base)
    if not tnorm:
        _MAP_CACHE[key] = None
        return None
    best_uri = None
    best_sim = 0.0
    candidate_iter = getattr(kg, "candidates_for_title", lambda _t: kg.all_movies())(title)
    for uri in candidate_iter:
        lbl = kg.label(uri) or ""
        lnorm = _normalize_simple(lbl)
        if not lnorm:
            continue
        if lnorm == tnorm:
            _MAP_CACHE[key] = uri
            return uri
        tw = set(tnorm.split())
        lw = set(lnorm.split())
        if not tw or not lw:
            continue
        inter = len(tw & lw)
        union = len(tw | lw)
        sim = inter / union if union else 0.0
        if sim >= 0.7 and abs(len(lnorm) - len(tnorm)) <= 10 and sim > best_sim:
            best_sim = sim
            best_uri = uri
    _MAP_CACHE[key] = best_uri
    return best_uri

def _detect_rating_intent(q: str) -> Optional[Tuple[str, object]]:
    ql = q.lower()
    m = re.search(r"\b(top|best|highest)\s*(\d+)?\s*(?:rated)?\s*(movies|films)\b", ql)
    if m:
        rest = ql[m.end():]
        if not (re.search(r"\bby\s+[a-z]", rest) or re.search(r"\b(his|her)\b", rest)):
            n = int(m.group(2)) if m.group(2) else 3
            return ("top", n)
    m = re.search(r"\b(bottom|worst|lowest)\s*(\d+)?\s*(?:rated)?\s*(movies|films)\b", ql)
    if m:
        rest = ql[m.end():]
        if not (re.search(r"\bby\s+[a-z]", rest) or re.search(r"\b(his|her)\b", rest)):
            n = int(m.group(2)) if m.group(2) else 3
            return ("bottom", n)
    m = (re.search(r"average\s+rating\s+(?:of|for)\s+\"?([^\"]+)\"?", ql)
         or re.search(r"rating\s+of\s+\"?([^\"]+)\"?", ql)
         or re.search(r"how\s+(?:highly\s+)?rated\s+is\s+\"?([^\"]+)\"?", ql))
    if m:
        return ("average", m.group(1).strip().rstrip("?"))
    return None

def _resolve_title_in_avg(avg: Dict[str, float], title: str) -> Optional[str]:
    def nrm(s: str) -> str:
        s = re.sub(r"\s*\([^)]*\)\s*", "", s)
        s = re.sub(r"^(the|a|an)\s+", "", s, flags=re.I)
        s = re.sub(r"[^\w\s]", "", s)
        return s.strip().lower()
    qn = nrm(title)
    for t in avg.keys():
        if nrm(t) == qn:
            return t
    matches = [(t, abs(len(nrm(t)) - len(qn))) for t in avg.keys() if qn in nrm(t) or nrm(t) in qn]
    return sorted(matches, key=lambda x: x[1])[0][0] if matches else None

def _entity_label(kg: KGFeatureStore, uri: str) -> str:
    g = getattr(kg, "g", None)
    if g is None:
        return uri.split("/")[-1]
    try:
        import rdflib
        subj = rdflib.URIRef(uri)
        best_en = None
        fallback = None
        try:
            from .engine import LABEL_PROPS  # type: ignore
        except Exception:
            from engine import LABEL_PROPS  # type: ignore
        for p in LABEL_PROPS:
            pred = rdflib.URIRef(p)
            for _, _, obj in g.triples((subj, pred, None)):
                txt = str(obj).strip()
                if not txt:
                    continue
                if getattr(obj, "language", None) == "en":
                    best_en = best_en or txt
                fallback = fallback or txt
            if best_en:
                break
        return best_en or fallback or uri.split("/")[-1]
    except Exception:
        return uri.split("/")[-1]

def _movies_by_person(kg: KGFeatureStore, person_name: str, role: str = "director") -> List[str]:
    fast = getattr(kg, "movies_by_person", None)
    if callable(fast):
        return fast(role, person_name)
    person_norm = _norm_strip(person_name)
    res: List[str] = []
    for m_uri in kg.all_movies():
        feats = kg.features_of(m_uri)
        for p_uri in feats.get(role, set()):
            label = _entity_label(kg, p_uri)
            if not label:
                continue
            ln = _norm_strip(label)
            if person_norm == ln or person_norm in ln or ln in person_norm:
                res.append(m_uri)
                break
    return res

# --------- FAST PATH: also handle plain person names (no rdflib) -------------
def _fast_director_scan(query: str, topn: int) -> Optional[Tuple[List[Tuple[str, float]], List[str], List[str]]]:
    """
    Ultra-fast path that reads the .nt file directly (no rdflib):
    - Handles "top N ... by NAME"
    - Also handles plain "NAME" (assume director first, then writer)
    """
    q_raw = (query or "").strip()
    q = q_raw.lower()

    m = re.search(r'(?:top|best)\s+(\d+)\s+(?:movies?|films?)\s+by\s+(.+?)(?:\?|$)', q)
    n = int(m.group(1)) if m else topn
    person = m.group(2).strip() if m else q_raw

    # person-like? (>=2 tokens with letters)
    if not m:
        toks = [t for t in re.split(r"\s+", person) if re.search(r"[A-Za-z]", t)]
        if len(toks) < 2:
            return None

    graph_path = os.environ.get("ATAI_KG_PATH") or os.environ.get("GRAPH_FILE_PATH")
    if not graph_path or not os.path.exists(graph_path):
        return None

    person_lc = person.lower()
    person_uris = set()

    # Pass 1: collect candidate person URIs by English labels
    with open(graph_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "rdfs#label" in line and "@en" in line and person_lc in line.lower():
                # <subj> <pred> "Label"@en .
                subj = line.split()[0].strip("<>")
                label = re.sub(r'^.*?"(.*?)"@en.*$', r"\1", line).strip().lower()
                if person_lc in label:
                    person_uris.add(subj)

    if not person_uris:
        return None

    # Pass 2: collect movies linked via P57 (director) or P58 (writer)
    m_dir, m_wri = set(), set()
    with open(graph_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "http://www.wikidata.org/prop/direct/P57" in line:
                for pu in person_uris:
                    if pu in line:
                        m_dir.add(line.split()[0].strip("<>"))
            elif "http://www.wikidata.org/prop/direct/P58" in line:
                for pu in person_uris:
                    if pu in line:
                        m_wri.add(line.split()[0].strip("<>"))

    movie_uris = m_dir or m_wri
    if not movie_uris:
        return None

    # Pass 3: map movie URIs → English labels
    movie_labels = {}
    with open(graph_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "rdfs#label" in line and "@en" in line:
                for mu in list(movie_uris - movie_labels.keys()):
                    if mu in line:
                        movie_labels[mu] = re.sub(r'^.*?"(.*?)"@en.*$', r"\1", line).strip()
                        if len(movie_labels) >= len(movie_uris):
                            break

    # Score by MovieLens (best match title → rating)
    avg, _ = load_movielens()
    results = []
    for mu, mt in movie_labels.items():
        m_norm = re.sub(r"\s*\(.*?\)|\W+", " ", mt).lower().strip()
        best = 0.0
        for ml_title, rating in avg.items():
            ml_norm = re.sub(r"\s*\(.*?\)|\W+", " ", ml_title).lower().strip()
            if (m_norm == ml_norm or m_norm in ml_norm or ml_norm in m_norm or
                len(set(m_norm.split()) & set(ml_norm.split())) >= 2):
                best = max(best, float(rating))
        results.append((mu, best))

    if not results:
        return None

    results.sort(key=lambda x: (-x[1], x[0]))
    return results[:n], [], []

# --------- KG singleton (avoid re-parsing) -----------------------------------
_KG_SINGLETON: Any = None
_KG_SINGLETON_PATH: Optional[str] = None

class _DummyKG:
    def __init__(self):
        self._labels: Dict[str, str] = {}
    def lookup_by_label(self, _label: str) -> Optional[str]:
        return None
    def all_movies(self) -> List[str]:
        return []
    def label(self, uri: str) -> str:
        return self._labels.get(uri, uri.split("/")[-1])
    def features_of(self, _uri: str) -> Dict[str, Set[str]]:
        return {}

def _get_kg(path: Optional[str]) -> Any:
    global _KG_SINGLETON, _KG_SINGLETON_PATH
    if path and _KG_SINGLETON is not None and _KG_SINGLETON_PATH == path:
        return _KG_SINGLETON
    try:
        if path and os.path.exists(path):
            kg = KGFeatureStore(path)
        else:
            kg = _DummyKG()
    except Exception:
        kg = _DummyKG()
    _KG_SINGLETON = kg
    _KG_SINGLETON_PATH = path
    return kg

# --------- Main entry --------------------------------------------------------
def recommend_from_text(query: str, topn: int = 3) -> Tuple[List[Tuple[str, float]], List[str], List[str]]:
    # make sure KG path is discoverable
    for c in [os.environ.get("ATAI_KG_PATH"),
              os.environ.get("GRAPH_FILE_PATH"),
              os.path.join(os.getcwd(), "data", "graph.nt"),
              os.path.join(os.getcwd(), "graph.nt")]:
        if c and os.path.exists(c):
            os.environ.setdefault("ATAI_KG_PATH", c)
            os.environ.setdefault("GRAPH_FILE_PATH", c)
            break

    # ⚡ ultra-fast path (handles "top N ... by NAME" and plain "NAME")
    fast = _fast_director_scan(query, topn)
    if fast is not None:
        return fast

    kg = _get_kg(os.environ.get("ATAI_KG_PATH"))
    avg, genres_map = load_movielens()

    try:
        rec = HybridRecommender(kg, FeedbackStore(), avg_ratings=avg, ml_genres=genres_map)
    except Exception:
        rec = None

    q = (query or "").strip()

    # ratings intent
    rinfo = _detect_rating_intent(q)
    if rinfo:
        mode, param = rinfo
        if mode in ("top", "bottom"):
            n = int(param) if isinstance(param, int) and param > 0 else topn
            ranked = sorted(avg.items(), key=(lambda x: (-x[1], x[0])) if mode == "top" else (lambda x: (x[1], x[0])))
            return [(kg.lookup_by_label(t) or t, float(r)) for t, r in ranked[:n]], [], []
        if mode == "average":
            tit = str(param)
            t = _resolve_title_in_avg(avg, tit)
            if t is not None:
                return [(kg.lookup_by_label(t) or t, float(avg[t]))], [], []
            else:
                return [], [], [tit]

    # explicit person patterns
    pm = re.search(r"(?:movies?|films?)\s+(directed by|written by)\s+([A-Z][\w.\- ]+)", q, flags=re.I)
    if pm:
        role_word = pm.group(1).lower()
        role = "director" if "direct" in role_word else "writer"
        person = pm.group(2).strip()
        movies = _movies_by_person(kg, person, role=role)
        if not movies:
            return [], [], [person]
        results: List[Tuple[str, float]] = []
        for u in movies:
            title = kg.label(u)
            score = float(avg.get(title, 0.0))
            results.append((u, score))
        results.sort(key=lambda x: (-x[1], kg.label(x[0])))
        return results[:topn], [], []

    pm2 = re.search(r"(?:top|best|highest[-\s]?rated?)\s*(\d+)?\s*(?:movies?|films?)?\s*(?:by|from)\s+([A-Z][\w.\- ]+)", q, flags=re.I)
    if pm2:
        n = int(pm2.group(1)) if pm2.group(1) else topn
        person = pm2.group(2).strip()
        movies = _movies_by_person(kg, person, role="director")
        if not movies:
            return [], [], [person]
        results: List[Tuple[str, float]] = []
        for u in movies:
            title = kg.label(u)
            score = float(avg.get(title, 0.0))
            results.append((u, score))
        results.sort(key=lambda x: (-x[1], kg.label(x[0])))
        return results[:n], [], []

    # title seeds
    titles = _smart_split_titles(q)
    disney_mode = _is_disney_context(titles) if titles else False

    seed_uris: List[str] = []
    unresolved: List[str] = []

    for t in titles:
        u = _best_title_match(kg, avg, genres_map, t, disney_mode)
        if u:
            seed_uris.append(u)
        else:
            unresolved.append(t)

    # fallbacks: if query looks like a person name or we have unresolved tokens, try people
    if not titles:
        toks = [t for t in re.split(r"\s+", q) if re.search(r"[A-Za-z]", t)]
        if len(toks) >= 2:
            movies = (_movies_by_person(kg, q, role="director") or
                      _movies_by_person(kg, q, role="writer") or
                      _movies_by_person(kg, q, role="actor"))
            if movies:
                results = [(u, float(avg.get(kg.label(u), 0.0))) for u in movies]
                results.sort(key=lambda x: (-x[1], kg.label(x[0])))
                return results[:topn], [], []

    if unresolved:
        agg: List[Tuple[str, float]] = []
        seen: Set[str] = set()
        for person in unresolved:
            movies = (_movies_by_person(kg, person, role="director") or
                      _movies_by_person(kg, person, role="writer") or
                      _movies_by_person(kg, person, role="actor"))
            for u in movies:
                if u not in seen:
                    agg.append((u, float(avg.get(kg.label(u), 0.0))))
                    seen.add(u)
        if agg:
            agg.sort(key=lambda x: (-x[1], kg.label(x[0])))
            return agg[:topn], [], []

    # heuristic families
    def _parse_year(title: str) -> Optional[int]:
        m = re.search(r"\((\d{4})\)", title)
        if m:
            try:
                return int(m.group(1))
            except Exception:
                return None
        return None
    def _resolve_ml_title(name: str) -> Optional[str]:
        return _resolve_title_in_avg(avg, name) if name else None
    def _ml_disney_recs(seeds: List[str], topn: int) -> List[Tuple[str, float]]:
        seed_genres: Set[str] = set()
        exclude: Set[str] = set()
        for s in seeds:
            ml = _resolve_ml_title(s)
            if ml:
                exclude.add(ml); g = _MOVIELENS_GENRES.get(ml) if _MOVIELENS_GENRES else None
                if g:
                    seed_genres.update([gg.lower() for gg in g])
        if not seed_genres:
            seed_genres.update(["animation", "children", "family", "fantasy"])
        results: List[Tuple[str, float]] = []
        for title, rating in avg.items():
            if title in exclude:
                continue
            g = _MOVIELENS_GENRES.get(title) if _MOVIELENS_GENRES else None
            if not g:
                continue
            genres_lower = [gg.lower() for gg in g]
            if not any(x in genres_lower for x in ["animation", "children", "family", "fantasy"]):
                continue
            inter = set(genres_lower) & seed_genres
            union = set(genres_lower) | seed_genres
            if not union:
                continue
            j = len(inter) / len(union)
            if j == 0.0:
                continue
            rating_norm = rating / 5.0 if rating is not None else 0.0
            score = 0.7 * j + 0.3 * rating_norm
            results.append((title, score))
        results.sort(key=lambda x: (-x[1], x[0]))
        return results[:topn]
    def _ml_horror_recs(seeds: List[str], topn: int) -> List[Tuple[str, float]]:
        seed_years: List[int] = []
        exclude: Set[str] = set()
        for s in seeds:
            ml = _resolve_ml_title(s)
            if ml:
                exclude.add(ml); y = _parse_year(ml)
                if y is not None:
                    seed_years.append(y)
        if not seed_years:
            seed_years = [1980]
        results: List[Tuple[str, float]] = []
        for title, rating in avg.items():
            if title in exclude:
                continue
            g = _MOVIELENS_GENRES.get(title) if _MOVIELENS_GENRES else None
            if not g or "Horror" not in g:
                continue
            y = _parse_year(title)
            year_score = 1.0
            if y is not None and seed_years:
                diffs = [abs(y - sy) for sy in seed_years]
                year_score = max(0.0, 1.0 - (min(diffs) / 30.0))
            rating_norm = rating / 5.0 if rating is not None else 0.0
            score = 0.7 * year_score + 0.3 * rating_norm
            if score <= 0.0:
                continue
            results.append((title, score))
        results.sort(key=lambda x: (-x[1], x[0]))
        return results[:topn]
    def _ml_shakespeare_recs(seeds: List[str], topn: int) -> List[Tuple[str, float]]:
        patterns = ["hamlet", "othello", "macbeth", "romeo and juliet", "romeo", "juliet",
                    "king lear", "henry v", "henry iv", "henry iii", "henry ii", "henry i",
                    "richard iii", "titus", "coriolanus", "julius caesar", "taming of the shrew"]
        exclude: Set[str] = set()
        for s in seeds:
            ml = _resolve_ml_title(s)
            if ml:
                exclude.add(ml)
        allowed_genres = {"Drama", "Romance", "History", "War"}
        results: List[Tuple[str, float]] = []
        for title, rating in avg.items():
            if title in exclude:
                continue
            g = _MOVIELENS_GENRES.get(title) if _MOVIELENS_GENRES else None
            if not g or not (set(g) & allowed_genres):
                continue
            base = re.sub(r"\s*\(\d{4}\)", "", title.lower()).strip()
            matched = sum(1 for p in patterns if p in base)
            if matched == 0:
                continue
            rating_norm = rating / 5.0 if rating is not None else 0.0
            score = matched * 1.5 + rating_norm * 0.5
            results.append((title, score))
        results.sort(key=lambda x: (-x[1], x[0]))
        return results[:topn]

    ql = q.lower()
    horror_keywords = ["nightmare on elm street", "nightmare", "friday the 13th", "halloween", "horror", "slasher"]
    is_horror_query = any(k in ql for k in horror_keywords)
    is_horror_seed = False
    for s in titles:
        ml_t = _resolve_title_in_avg(avg, s)
        if ml_t and _MOVIELENS_GENRES.get(ml_t) and "Horror" in _MOVIELENS_GENRES[ml_t]:
            is_horror_seed = True
            break
    shakespeare_keywords = ["hamlet", "othello", "macbeth", "romeo", "juliet", "king lear", "shakespeare"]
    is_shakespeare_query = any(k in ql for k in shakespeare_keywords)
    is_shakespeare_seed = any(_normalize_simple(s) in ["hamlet","othello","macbeth","romeo and juliet","king lear"] for s in titles)

    if titles:
        if disney_mode:
            ml_recs = _ml_disney_recs(titles, topn)
            if ml_recs:
                out = [(_safe_map_title_to_kg(kg, lbl) or lbl, float(sc)) for lbl, sc in ml_recs]
                return out, seed_uris, unresolved
        if is_horror_query or is_horror_seed:
            ml_recs = _ml_horror_recs(titles, topn)
            if ml_recs:
                out = [(_safe_map_title_to_kg(kg, lbl) or lbl, float(sc)) for lbl, sc in ml_recs]
                return out, seed_uris, unresolved
        if is_shakespeare_query or is_shakespeare_seed:
            ml_recs = _ml_shakespeare_recs(titles, topn)
            if ml_recs:
                out = [(_safe_map_title_to_kg(kg, lbl) or lbl, float(sc)) for lbl, sc in ml_recs]
                return out, seed_uris, unresolved

    if disney_mode and not seed_uris:
        dc = disney_candidates(avg, genres_map, titles, topn)
        return [(_safe_map_title_to_kg(kg, lbl) or lbl, float(r)) for lbl, r in dc], seed_uris, unresolved

    if seed_uris:
        if rec is not None:
            recs = rec.recommend(user_id="cli", seeds=seed_uris)
            if disney_mode:
                filtered = []
                for uri, score in recs:
                    feats = kg.features_of(uri)
                    is_anim = any(("animation" in str(g).lower() or "children" in str(g).lower() or "family" in str(g).lower() or "fantasy" in str(g).lower())
                                  for g in feats.get("genre", set()))
                    lbl = (kg.label(uri) or "").lower()
                    has_kw = any(k in lbl for k in ["disney", "pixar", "animated"])
                    if is_anim or has_kw:
                        filtered.append((uri, score))
                if filtered:
                    return filtered[:topn], seed_uris, unresolved
            return recs[:topn], seed_uris, unresolved

    return [], seed_uris, unresolved
