"""
analytics.py — MovieLens averages and a simple directors helper.
Works when CWD == data/ or when MOVIELENS_DIR is set; also scans a few common spots.
"""
from __future__ import annotations

import csv
import os
from typing import List, Tuple, Dict, Optional
from collections import defaultdict
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .engine import KGFeatureStore  # pragma: no cover

def _load_movielens_data() -> Tuple[Dict[int, str], Dict[int, List[float]]]:
    if hasattr(_load_movielens_data, "_cache"):
        return _load_movielens_data._cache  # type: ignore

    movies: Dict[int, str] = {}
    ratings: Dict[int, List[float]] = defaultdict(list)

    data_dirs = []
    ml = os.environ.get("MOVIELENS_DIR")
    if ml:
        data_dirs.append(ml)
    data_dirs.append(os.getcwd())
    here = os.path.dirname(os.path.abspath(__file__))
    data_dirs.extend([
        here,
        os.path.join(here, "..", "..", ".."),
        os.path.join(here, "..", "..", "..", "data"),
        "/mnt/data",
        "/mnt/user-data/uploads",
    ])

    movies_path = ratings_path = None
    for d in data_dirs:
        m_path = os.path.join(d, "movies.csv")
        r_path = os.path.join(d, "ratings.csv")
        if os.path.exists(m_path) and os.path.exists(r_path):
            movies_path, ratings_path = m_path, r_path
            break

    if not movies_path or not ratings_path:
        return {}, defaultdict(list)

    try:
        with open(movies_path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                try:
                    movies[int(row["movieId"])] = row.get("title", "").strip()
                except Exception:
                    pass
    except FileNotFoundError:
        pass

    try:
        with open(ratings_path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                try:
                    ratings[int(row["movieId"])].append(float(row["rating"]))
                except Exception:
                    pass
    except FileNotFoundError:
        pass

    _load_movielens_data._cache = (movies, ratings)  # type: ignore
    return movies, ratings

def _average_ratings() -> Dict[str, float]:
    if hasattr(_average_ratings, "_cache"):
        return _average_ratings._cache  # type: ignore
    movies, ratings = _load_movielens_data()
    avg: Dict[str, float] = {}
    for mid, vals in ratings.items():
        if vals and mid in movies:
            avg[movies[mid]] = sum(vals) / len(vals)
    _average_ratings._cache = avg  # type: ignore
    return avg

def top_rated_movies(n: int = 1) -> List[Tuple[str, float]]:
    avgs = _average_ratings()
    return sorted(avgs.items(), key=lambda x: (-x[1], x[0]))[:n]

def bottom_rated_movies(n: int = 1) -> List[Tuple[str, float]]:
    avgs = _average_ratings()
    return sorted(avgs.items(), key=lambda x: (x[1], x[0]))[:n]
