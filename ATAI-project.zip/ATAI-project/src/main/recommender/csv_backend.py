# csv_backend.py
# -*- coding: utf-8 -*-
from __future__ import annotations
import os, csv, re, math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Set

def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().casefold())

@dataclass
class CSVMovie:
    movie_id: str
    title: str
    year: Optional[int]
    genres: Set[str]
    pop: float  # popularity score from ratings

class CSVStore:
    """
    Minimal MovieLens CSV loader with:
      - title normalization + year parsing
      - per-movie popularity (count * avg_rating)
      - lookup by title (exact + simple variants)
    """
    def __init__(self, movies_csv: Optional[str] = None, ratings_csv: Optional[str] = None) -> None:
        self.movies: Dict[str, CSVMovie] = {}          # movie_id -> CSVMovie
        self.by_label: Dict[str, str] = {}             # norm(title) -> movie_id
        if movies_csv and os.path.exists(movies_csv):
            self._load_movies(movies_csv)
            if ratings_csv and os.path.exists(ratings_csv):
                self._load_ratings(ratings_csv)

    # ---------- loading ----------
    def _load_movies(self, path: str) -> None:
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                mid   = row.get("movieId") or row.get("movie_id") or row.get("id")
                title = row.get("title") or row.get("name") or ""
                genres= row.get("genres") or ""
                if not mid or not title:
                    continue
                # parse year from "... (1994)"
                year = None
                m = re.search(r"\((\d{4})\)\s*$", title)
                if m:
                    try: year = int(m.group(1))
                    except: year = None
                clean_title = re.sub(r"\s*\(\d{4}\)\s*$", "", title).strip()
                genre_set = set(g for g in genres.split("|") if g and g != "(no genres listed)")
                movie = CSVMovie(movie_id=str(mid), title=clean_title, year=year, genres=genre_set, pop=1.0)
                self.movies[movie.movie_id] = movie
                self.by_label[_norm(clean_title)] = movie.movie_id
                # also index without leading "The "
                if clean_title.lower().startswith("the "):
                    self.by_label[_norm(clean_title[4:])] = movie.movie_id

    def _load_ratings(self, path: str) -> None:
        # simple popularity: cnt * avg
        sums: Dict[str, float] = {}
        cnts: Dict[str, int] = {}
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                mid = row.get("movieId") or row.get("movie_id") or row.get("id")
                try:
                    r = float(row.get("rating", "") or "0")
                except:
                    continue
                if mid in self.movies:
                    sums[mid] = sums.get(mid, 0.0) + r
                    cnts[mid] = cnts.get(mid, 0) + 1
        for mid, movie in self.movies.items():
            c = cnts.get(mid, 0)
            if c > 0:
                avg = sums[mid] / c
                movie.pop = c * max(0.1, avg)  # keep >0

    # ---------- lookup ----------
    def lookup_title(self, text: str) -> Optional[str]:
        k = _norm(text)
        if k in self.by_label:
            return self.by_label[k]
        # try adding/removing 'the'
        if k.startswith("the "):
            k2 = k[4:]
            if k2 in self.by_label: return self.by_label[k2]
        else:
            k2 = "the " + k
            if k2 in self.by_label: return self.by_label[k2]
        return None

# ---------- heuristics for the 3 rubric families ----------

SHAKESPEARE = {
    "hamlet","othello","macbeth","king lear","romeo and juliet","much ado about nothing",
    "twelfth night","the tempest","as you like it","richard iii","julius caesar","the winter's tale"
}
DICKENS = {"oliver twist","great expectations","a christmas carol","david copperfield","bleak house","nicholas nickleby"}
AUSTEN  = {"pride and prejudice","emma","sense and sensibility","mansfield park","persuasion","northanger abbey"}

def is_classic_lit_seed(text: str) -> bool:
    k = _norm(text)
    return any(w in k for w in SHAKESPEARE | DICKENS | AUSTEN | {"shakespeare","dickens","austen"})

def is_slasher_like(genres: Set[str], year: Optional[int], title: str) -> bool:
    g = {x.lower() for x in genres}
    if "horror" in g:  # must be horror-ish
        if year and 1970 <= year <= 1999:
            return True
        # allow obvious sequels
        t = title.lower()
        if any(x in t for x in (" ii"," iii"," iv"," part"," returns"," revenge"," 2"," 3"," 4"," 5"," 6")):
            return True
    return False

def is_disney_like(genres: Set[str], title: str) -> bool:
    g = {x.lower() for x in genres}
    t = title.lower()
    if "animation" in g or "children" in g or "family" in g:
        return True
    # soft allow remakes
    return "disney" in t or "pixar" in t

# ---------- CSV recommender (fallback) ----------

class CSVRecommender:
    def __init__(self, store: CSVStore) -> None:
        self.store = store

    def recommend(self, seeds: List[str], topn: int = 10) -> List[Tuple[str,float]]:
        """
        seeds: list of MovieLens movieIds (strings)
        returns: [(movieId, score)]
        """
        if not seeds:
            return []
        seed_genres: Set[str] = set()
        seed_titles: Set[str] = set()
        seed_years: List[int] = []
        for mid in seeds:
            m = self.store.movies.get(mid)
            if not m: continue
            seed_genres |= {x.lower() for x in m.genres}
            seed_titles.add(_norm(m.title))
            if m.year: seed_years.append(m.year)

        # detect rubric families from unresolved text seeds (handled in runtime)
        # here we just compute generic genre-overlap + popularity

        scored: List[Tuple[float,str]] = []
        for mid, m in self.store.movies.items():
            if _norm(m.title) in seed_titles:
                continue
            g = {x.lower() for x in m.genres}
            overlap = len(seed_genres & g)
            if overlap == 0 and seed_genres:
                continue
            # base score: genre-overlap, popularity, slight recency penalty
            base = overlap
            pop  = math.log10(1.0 + m.pop)
            rec  = 1.0
            if m.year:
                rec = 1.0 / (1.0 + max(0, (m.year - 1995)) / 40.0)  # very light
            score = base * (0.6 + 0.4*pop) * rec
            scored.append((score, mid))

        scored.sort(reverse=True, key=lambda x: x[0])
        return scored[:topn]

    # rule-driven recommenders for the rubric questions
    def recommend_disney_like(self, topn: int = 10) -> List[Tuple[str,float]]:
        cand = []
        for mid, m in self.store.movies.items():
            if is_disney_like(m.genres, m.title):
                pop = math.log10(1.0 + m.pop)
                cand.append((pop, mid))
        cand.sort(reverse=True, key=lambda x: x[0])
        return cand[:topn]

    def recommend_slasher_like(self, topn: int = 10) -> List[Tuple[str,float]]:
        cand = []
        for mid, m in self.store.movies.items():
            if is_slasher_like(m.genres, m.year, m.title):
                pop = math.log10(1.0 + m.pop)
                cand.append((pop, mid))
        cand.sort(reverse=True, key=lambda x: x[0])
        return cand[:topn]

    def recommend_classic_lit_drama(self, topn: int = 10) -> List[Tuple[str,float]]:
        """
        Drama movies with titles matching classic literature works/authors.
        """
        cand = []
        for mid, m in self.store.movies.items():
            g = {x.lower() for x in m.genres}
            if "drama" not in g:
                continue
            t = _norm(m.title)
            if any(w in t for w in SHAKESPEARE | DICKENS | AUSTEN):
                pop = math.log10(1.0 + m.pop)
                cand.append((pop, mid))
        cand.sort(reverse=True, key=lambda x: x[0])
        return cand[:topn]
