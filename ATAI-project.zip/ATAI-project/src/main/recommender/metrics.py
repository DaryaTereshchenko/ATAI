from typing import List, Set, Tuple
import math

def precision_recall_at_k(recommended: List[str], relevant: Set[str], k: int = 10) -> Tuple[float, float]:
    rec_k = recommended[:k]
    hits = sum(1 for x in rec_k if x in relevant)
    precision = hits / max(1, len(rec_k))
    recall = hits / max(1, len(relevant))
    return precision, recall

def arhr(recommended: List[str], relevant: Set[str], k: int = 10) -> float:
    return sum(1.0/(i+1) for i, item in enumerate(recommended[:k]) if item in relevant)

def mae_rmse(pred_truth: List[Tuple[float, float]]) -> Tuple[float, float]:
    if not pred_truth:
        return 0.0, 0.0
    abs_err = [abs(p - t) for p, t in pred_truth]
    sq_err = [(p - t) ** 2 for p, t in pred_truth]
    mae = sum(abs_err) / len(abs_err)
    rmse = math.sqrt(sum(sq_err) / len(sq_err))
    return mae, rmse
