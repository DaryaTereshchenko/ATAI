import os
import csv
import re
from typing import Dict, List, Tuple, Optional, Set

# ----------------------------- STOPWORDS / TEXT HELPERS -----------------------------

STOPWORDS = {
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
    'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'be', 'been',
    'i', 'you', 'he', 'she', 'it', 'we', 'they', 'like', 'given', 'that',
    'can', 'some', 'movies', 'film', 'films', 'movie', 'recommend', 'his',
    'her', 'their', 'give', 'me', 'show', 'tell', 'want', 'need', 'top',
    'best', 'good', 'great', 'list', 'highest', 'rated', 'rating'
}

def _normalize_title(title: str) -> str:
    s = (title or "").lower().strip()
    s = re.sub(r"\s*\(\d{4}\)$", "", s)
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def _get_content_words(text: str) -> Set[str]:
    words = re.findall(r"[a-zA-Z0-9']+", (text or "").lower())
    return {w for w in words if len(w) >= 3 and w not in STOPWORDS}

def _create_search_phrases(title: str) -> List[str]:
    normalized = _normalize_title(title)
    phrases = [normalized]
    for article in ['the', 'a', 'an']:
        if normalized.endswith(f' {article}'):
            base = normalized[:-len(article)-1]
            if base:
                phrases.append(f'{article} {base}')
                phrases.append(base)
    valid = []
    for phrase in phrases:
        content = _get_content_words(phrase)
        if len(content) >= 2 or len(phrase.split()) == 1:
            valid.append(phrase)
    return valid

def _extract_year(title: str) -> Optional[int]:
    m = re.search(r'\((\d{4})\)', title or "")
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            return None
    return None

# -------------------------- DIRECTOR / WRITER / ACTOR DETECTION --------------------------

_DIRECTOR_PATTERNS = [
    r"(?:directed\s+by|by\s+director)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)",
    r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s*(?:'s)?\s+(?:movies|films)",
    r"(?:movies|films)\s+by\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)",
]
_WRITER_PATTERNS = [
    r"(?:written\s+by|screenplay\s+by|by\s+screenwriter)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)",
    r"(?:films|movies)\s+(?:written|scripted)\s+by\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)",
    r"screenwriter:\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)",
]
# liberal actor phrases incl. lists
_ACTOR_PATTERNS = [
    r"(?:starring|with|featuring)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+(?:\s*(?:,|and)\s*[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)*)",
    r"(?:movies?|films?)\s+(?:with|starring|featuring)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+(?:\s*(?:,|and)\s*[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)*)",
    r"(?:i\s+like|i\s+love)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+(?:\s*(?:,|and)\s*[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)*)"
]

def _detect_director_query(text: str, known_directors: Optional[Set[str]] = None) -> Optional[str]:
    if not text:
        return None
    for pat in _DIRECTOR_PATTERNS:
        m = re.search(pat, text)
        if m:
            return m.group(1).strip()
    if known_directors:
        tl = text.lower()
        best = None
        best_len = 0
        for d in known_directors:
            if d in tl and len(d) > best_len:
                best = d
                best_len = len(d)
        if best:
            for k in known_directors:
                if k == best:
                    return k
            return best.title()
    return None

def _detect_writer_name(text: str) -> Optional[str]:
    if not text:
        return None
    for pat in _WRITER_PATTERNS:
        m = re.search(pat, text)
        if m:
            return m.group(1).strip()
    return None

def _detect_actor_names(text: str) -> List[str]:
    if not text:
        return []
    t = text.strip()
    for pat in _ACTOR_PATTERNS:
        m = re.search(pat, t, re.I)
        if m:
            chunk = m.group(1)
            parts = re.split(r"\s*(?:,|and)\s*", chunk)
            names = []
            for p in parts:
                p = p.strip()
                if len(p.split()) >= 2:
                    names.append(p)
            return names
    # fallback simple form: "i like tom cruise" / "tom cruise movies"
    m2 = re.search(r"(?:i\s+like|i\s+love|with|starring|featuring)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)", t)
    return [m2.group(1).strip()] if m2 else []

# ------------------------------- AWARD DETECTION --------------------------------

_AWARD_ALIASES = {
    "oscar": "academy awards",
    "oscars": "academy awards",
    "academy award": "academy awards",
    "academy awards": "academy awards",
    "academy award for best picture": "academy best picture",
    "best picture oscar": "academy best picture",
    "best picture award": "academy best picture",
    "golden globes": "golden globe awards",
    "golden globe": "golden globe awards",
    "golden globe award for best motion picture – drama": "gg drama",
    "golden globe award for best motion picture - drama": "gg drama",
}
_AWARD_CATEGORY_HINTS = [
    ("best picture", "academy best picture"),
    ("best motion picture – drama", "gg drama"),
    ("best motion picture - drama", "gg drama"),
    ("best drama", "gg drama"),
]
_AWARD_PAT = re.compile(r"(oscar|oscars|academy award(?:s)?|golden globe(?:s)?)(.*)", re.I)

# ---------------------------------- INDEX CLASS ------------------------------------

class MovieVectorIndex:
    """
    Unified recommender with separate logic for:
      • Awards (winners-only; category-aware)
      • Screenwriter (if detected)
      • Actor (KG-backed; multi-actor intersection)
      • Director (KG-backed where available)
      • Ratings (explicit 'top rated' queries)
      • Theme/Genre/Time (original path)

    Seed titles mentioned in the query are excluded from results.
    """

    def pretty_print(idx, rows):
        header = f"{'#':>3}  {'Title':55}  {'Year':>4}  {'Avg':>5}  {'Votes':>6}  Genres"
        print(header)
        print("-" * len(header))
        for i, (title, _) in enumerate(rows, 1):
            year = idx.years.get(title, "????")
            avg = idx.rating.get(title, 0.0)
            n   = idx.rating_counts.get(title, 0)
            genres = ", ".join(idx.genres.get(title, [])[:3])
            print(f"{i:>3}  {title[:55]:55}  {year:>4}  {avg:>5.2f}  {n:>6}  {genres}")

    def __init__(self, max_movies: Optional[int] = None):
        # Core storage
        self.titles: List[str] = []
        self.search_phrases: List[List[str]] = []
        self.genres: Dict[str, List[str]] = {}
        self.rating: Dict[str, float] = {}
        self.rating_counts: Dict[str, int] = {}
        self.years: Dict[str, int] = {}

        self.title_terms: List[Set[str]] = []
        self.norm_titles: List[str] = []

        # Knowledge-graph powered maps
        self.directors: Dict[str, List[str]] = {}
        self.writers: Dict[str, List[str]] = {}
        self.actors: Dict[str, List[str]] = {}
        self.awards_map: Dict[str, Set[str]] = {}
        self.awards_won: Dict[str, Set[str]] = {}

        self.max_movies = max_movies or int(os.environ.get("MAX_MOVIES", "10000"))
        self._load_data()
        self._load_directors_from_graph()
        self._load_screenwriters_from_graph()
        self._load_actors_from_graph()
        self._load_awards_from_graph()

    # ------------------------------ DATA LOADING ------------------------------

    def _find_movielens(self) -> Tuple[str, str]:
        for d in [os.environ.get("MOVIELENS_DIR"),
                  "/mnt/user-data/uploads", ".", "data",
                  os.path.join(os.getcwd(), "data"), "/mnt/data"]:
            if not d:
                continue
            m, r = os.path.join(d, "movies.csv"), os.path.join(d, "ratings.csv")
            if os.path.isfile(m) and os.path.isfile(r):
                return m, r
        raise FileNotFoundError("movies.csv/ratings.csv not found")

    def _load_data(self) -> None:
        movies_csv, ratings_csv = self._find_movielens()
        id2title: Dict[str, str] = {}
        with open(movies_csv, encoding="utf-8") as f:
            rdr = csv.DictReader(f)
            for i, row in enumerate(rdr):
                if i >= self.max_movies:
                    break
                mid = str(row.get("movieId", ""))
                title = (row.get("title") or "").strip()
                if not title:
                    continue
                id2title[mid] = title
                self.titles.append(title)
                self.search_phrases.append(_create_search_phrases(title))
                self.norm_titles.append(_normalize_title(title))
                self.title_terms.append(_get_content_words(title))

                genre_str = row.get("genres", "")
                self.genres[title] = [
                    g.strip().lower()
                    for g in genre_str.split("|")
                    if g and g != "(no genres listed)"
                ]
                year = _extract_year(title)
                if year:
                    self.years[title] = year

        sums: Dict[str, float] = {}
        counts: Dict[str, int] = {}
        with open(ratings_csv, encoding="utf-8") as f:
            rdr = csv.DictReader(f)
            for row in rdr:
                mid = str(row.get("movieId", ""))
                title = id2title.get(mid)
                if not title:
                    continue
                try:
                    r = float(row.get("rating", 0))
                    sums[title] = sums.get(title, 0.0) + r
                    counts[title] = counts.get(title, 0) + 1
                except ValueError:
                    continue

        self.rating = {t: sums[t]/counts[t] for t in sums if counts[t] > 0}
        self.rating_counts = counts

        print(f"✓ Loaded {len(self.titles)} movies, {len(self.rating)} rated")

    # ------------------------------ KG PARSING HELPERS ------------------------------

    def _locate_graph(self) -> Optional[str]:
        graph_path = os.environ.get("ATAI_KG_PATH") or os.environ.get("GRAPH_FILE_PATH")
        if graph_path and os.path.isdir(graph_path):
            candidate = os.path.join(graph_path, "graph.nt")
            if os.path.isfile(candidate):
                return candidate
        for d in ["/mnt/user-data/uploads", ".", "data", os.path.join(os.getcwd(), "data"), "/mnt/data"]:
            candidate = os.path.join(d, "graph.nt")
            if os.path.isfile(candidate):
                return candidate
        return None

    def _parse_nt(self, path: str):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                m = re.match(r"<([^>]+)>\s+<([^>]+)>\s+(.*)\s+\.", line)
                if not m:
                    continue
                yield m.group(1), m.group(2), m.group(3)

    @staticmethod
    def _unquote_literal(obj: str) -> Optional[str]:
        m = re.match(r'"(.*)"(?:@\w+|(?:\^\^<[^>]+>))?$', obj)
        return m.group(1) if m else None

    # ------------------------------ DIRECTORS (P57) ------------------------------

    def _load_directors_from_graph(self) -> None:
        path = self._locate_graph()
        if not path:
            print("Knowledge graph not found — director queries will use basic matching.")
            return

        label_of: Dict[str, str] = {}
        film_to_director_uris: Dict[str, Set[str]] = {}

        for s, p, o in self._parse_nt(path):
            if p.endswith("#label") or p.endswith("/rdfs#label"):
                lit = self._unquote_literal(o)
                if lit:
                    label_of[s] = lit
                continue
            if p.endswith("/P57"):
                m2 = re.match(r"<([^>]+)>", o)
                if not m2:
                    continue
                d_uri = m2.group(1)
                film_to_director_uris.setdefault(s, set()).add(d_uri)

        norm_to_titles: Dict[str, List[str]] = {}
        for t in self.titles:
            nt = _normalize_title(t)
            norm_to_titles.setdefault(nt, []).append(t)

        for film_uri, dir_uris in film_to_director_uris.items():
            film_label = label_of.get(film_uri)
            if not film_label:
                continue
            film_norm = _normalize_title(film_label)
            if film_norm not in norm_to_titles:
                continue

            for ml_title in norm_to_titles[film_norm]:
                for d_uri in dir_uris:
                    dname = label_of.get(d_uri)
                    if not dname:
                        continue
                    dnorm = dname.lower().strip()
                    self.directors.setdefault(dnorm, []).append(ml_title)

        for k in list(self.directors.keys()):
            seen = set()
            unique = []
            for t in self.directors[k]:
                if t not in seen:
                    seen.add(t)
                    unique.append(t)
            self.directors[k] = unique
        print(f"✓ Loaded director data for {len(self.directors)} directors from graph.nt")

    # ------------------------------ SCREENWRITERS (P58) ------------------------------

    def _load_screenwriters_from_graph(self) -> None:
        path = self._locate_graph()
        if not path:
            return

        label_of: Dict[str, str] = {}
        film_to_writer_uris: Dict[str, Set[str]] = {}

        for s, p, o in self._parse_nt(path):
            if p.endswith("#label") or p.endswith("/rdfs#label"):
                lit = self._unquote_literal(o)
                if lit:
                    label_of[s] = lit
                continue
            if p.endswith("/P58"):
                m2 = re.match(r"<([^>]+)>", o)
                if not m2:
                    continue
                w_uri = m2.group(1)
                film_to_writer_uris.setdefault(s, set()).add(w_uri)

        norm_to_titles: Dict[str, List[str]] = {}
        for t in self.titles:
            nt = _normalize_title(t)
            norm_to_titles.setdefault(nt, []).append(t)

        for film_uri, wr_uris in film_to_writer_uris.items():
            film_label = label_of.get(film_uri)
            if not film_label:
                continue
            film_norm = _normalize_title(film_label)
            if film_norm not in norm_to_titles:
                continue

            for ml_title in norm_to_titles[film_norm]:
                for w_uri in wr_uris:
                    wname = label_of.get(w_uri)
                    if not wname:
                        continue
                    wnorm = wname.lower().strip()
                    self.writers.setdefault(wnorm, []).append(ml_title)

        for k in list(self.writers.keys()):
            seen = set()
            unique = []
            for t in self.writers[k]:
                if t not in seen:
                    seen.add(t)
                    unique.append(t)
            self.writers[k] = unique

        if self.writers:
            print(f"✓ Loaded screenwriter data for {len(self.writers)} writers from graph.nt")

    # ------------------------------ ACTORS (P161) ------------------------------

    def _load_actors_from_graph(self) -> None:
        path = self._locate_graph()
        if not path:
            print(" Knowledge graph not found — actor queries will use text heuristics.")
            return

        label_of: Dict[str, str] = {}
        film_to_actor_uris: Dict[str, Set[str]] = {}

        for s, p, o in self._parse_nt(path):
            if p.endswith("#label") or p.endswith("/rdfs#label"):
                lit = self._unquote_literal(o)
                if lit:
                    label_of[s] = lit
                continue
            if p.endswith("/P161"):
                m2 = re.match(r"<([^>]+)>", o)
                if not m2:
                    continue
                a_uri = m2.group(1)
                film_to_actor_uris.setdefault(s, set()).add(a_uri)

        norm_to_titles: Dict[str, List[str]] = {}
        for t in self.titles:
            nt = _normalize_title(t)
            norm_to_titles.setdefault(nt, []).append(t)

        for film_uri, act_uris in film_to_actor_uris.items():
            film_label = label_of.get(film_uri)
            if not film_label:
                continue
            film_norm = _normalize_title(film_label)
            if film_norm not in norm_to_titles:
                continue

            for ml_title in norm_to_titles[film_norm]:
                for a_uri in act_uris:
                    aname = label_of.get(a_uri)
                    if not aname:
                        continue
                    anorm = aname.lower().strip()
                    self.actors.setdefault(anorm, []).append(ml_title)

        for k in list(self.actors.keys()):
            seen = set()
            unique = []
            for t in self.actors[k]:
                if t not in seen:
                    seen.add(t)
                    unique.append(t)
            self.actors[k] = unique

        print(f"✓ Loaded actor data for {len(self.actors)} actors from graph.nt")

    # ------------------------------ AWARDS (P166) ------------------------------

    def _load_awards_from_graph(self) -> None:
        path = self._locate_graph()
        if not path:
            print(" Knowledge graph not found — award queries will be heuristic only.")
            return

        label_of: Dict[str, str] = {}
        film_uri_to_award_uris: Dict[str, Set[str]] = {}

        for s, p, o in self._parse_nt(path):
            if p.endswith("#label") or p.endswith("/rdfs#label"):
                lit = self._unquote_literal(o)
                if lit:
                    label_of[s] = lit
                continue
            if p.endswith("/P166"):
                m2 = re.match(r"<([^>]+)>", o)
                if not m2:
                    continue
                a_uri = m2.group(1)
                film_uri_to_award_uris.setdefault(s, set()).add(a_uri)

        norm_to_titles: Dict[str, List[str]] = {}
        for t in self.titles:
            nt = _normalize_title(t)
            norm_to_titles.setdefault(nt, []).append(t)

        def _normalize_award_label(lbl: str) -> Optional[str]:
            s = (lbl or "").lower()
            if "academy award" in s or "oscar" in s or "oscars" in s:
                if "best picture" in s:
                    return "academy best picture"
                return "academy awards"
            if "golden globe" in s:
                if "best motion picture" in s and "drama" in s:
                    return "gg drama"
                return "golden globe awards"
            return None

        attached = 0
        for film_uri, a_uris in film_uri_to_award_uris.items():
            film_label = label_of.get(film_uri)
            if not film_label:
                continue
            film_norm = _normalize_title(film_label)
            if film_norm not in norm_to_titles:
                continue

            for ml_title in norm_to_titles[film_norm]:
                for a_uri in a_uris:
                    a_lbl = label_of.get(a_uri, "")
                    tag = _normalize_award_label(a_lbl)
                    if not tag:
                        continue
                    self.awards_map.setdefault(ml_title, set()).add(tag)
                    self.awards_won.setdefault(ml_title, set()).add(tag)
                    attached += 1

        print(f"✓ Loaded award data for {len(self.awards_map)} films from graph.nt (wins mapped: {attached})")

    # ------------------------------ LOOKUPS ------------------------------

    def _find_director_movies(self, director_name: str) -> List[Tuple[str, float]]:
        if not director_name:
            return []
        key = director_name.lower().strip()
        if key in self.directors:
            titles = self.directors[key]
        else:
            parts = set(key.split())
            best, best_overlap = None, 0
            for d in self.directors.keys():
                ov = len(parts & set(d.split()))
                if ov > best_overlap:
                    best, best_overlap = d, ov
            titles = self.directors.get(best or "", [])
        scored = [(t, float(self.rating.get(t, 0.0))) for t in titles]
        scored.sort(key=lambda x: (-x[1], x[0]))
        return scored

    def _find_writer_movies(self, writer_name: str) -> List[Tuple[str, float]]:
        if not writer_name:
            return []
        key = writer_name.lower().strip()
        titles = self.writers.get(key, [])
        scored = [(t, float(self.rating.get(t, 0.0))) for t in titles]
        scored.sort(key=lambda x: (-x[1], x[0]))
        return scored

    def _find_actor_movies(self, actor_names: List[str]) -> List[Tuple[str, float]]:
        """
        Multi-actor ranking:
          - Prefer movies matching ALL requested actors; if none, fall back to ANY.
          - Score = matches_count + 0.15 * avg_rating
        """
        if not actor_names:
            return []

        # collect sets
        name_keys = [n.lower().strip() for n in actor_names]
        movie_to_hits: Dict[str, int] = {}
        for nk in name_keys:
            titles = self.actors.get(nk, [])
            for t in titles:
                movie_to_hits[t] = movie_to_hits.get(t, 0) + 1

        if not movie_to_hits:
            return []

        max_hits = max(movie_to_hits.values())
        # try strict intersection (all actors)
        pool = [t for t, h in movie_to_hits.items() if h == max_hits]
        # rank
        ranked = []
        for t in pool:
            score = max_hits + 0.15 * float(self.rating.get(t, 0.0))
            ranked.append((t, score))
        ranked.sort(key=lambda x: (-x[1], x[0]))

        # If intersection too small (e.g., none), expand to any
        if not ranked:
            for t, h in movie_to_hits.items():
                score = h + 0.15 * float(self.rating.get(t, 0.0))
                ranked.append((t, score))
            ranked.sort(key=lambda x: (-x[1], x[0]))

        return ranked

    # ------------------------------ AWARD INTENT + QUERY ------------------------------

    def _detect_award_intent(self, text: str) -> Optional[Dict]:
        t = (text or "").lower()
        m = _AWARD_PAT.search(t)
        if not m:
            return None

        category = None
        for key, tag in _AWARD_CATEGORY_HINTS:
            if key in t:
                category = tag
                break
        if not category:
            for k, v in _AWARD_ALIASES.items():
                if k in t:
                    category = v
                    break

        # Default vague Oscar -> Best Picture
        if not category or category == "academy awards":
            category = "academy best picture"

        mnum = re.search(r"\b(top|give|show|list)?\s*(\d{1,2})\b", t)
        req_n = int(mnum.group(2)) if mnum else None
        return {"category": category, "req_n": req_n}

    def _award_query(self, intent: Dict, seeds_in_query: Set[str], topn: int) -> List[Tuple[str, float]]:
        cat = intent.get("category")
        req_n = intent.get("req_n") or topn

        def ok(title: str) -> bool:
            tags = self.awards_won.get(title, set())
            if not tags:
                return False
            if cat == "academy best picture":
                return "academy best picture" in tags
            if cat == "gg drama":
                return "gg drama" in tags
            return False

        candidates = [(t, self.rating.get(t, 0.0))
                      for t in self.titles
                      if ok(t) and t not in seeds_in_query]
        candidates.sort(key=lambda x: (-x[1], -self.rating_counts.get(x[0], 0), x[0]))
        return candidates[:req_n]

    # ------------------------------ TOP-RATED DETECTION ------------------------------

    def _detect_top_rated(self, text: str) -> Optional[Dict]:
        t = (text or "").lower()
        triggers = [
            "top rated", "top-rated", "highest rated", "highest-rated",
            "best rated", "best-rated", "top ratings", "top rating",
            "top movies overall", "top films overall", "top overall"
        ]
        if not any(trg in t for trg in triggers) and not re.search(r"\btop\s+\d{1,2}\b", t):
            return None

        # genre extraction (avoid capturing "highest-rated" as a genre)
        g = None
        mg = re.search(r"(?:top|highest[- ]rated|best[- ]rated)\s+(?:\d{1,2}\s+)?([a-z][a-z\- ]+?)\s+movies?", t)
        if mg:
            cand = mg.group(1).strip()
            if cand not in {"highest-rated", "top", "best-rated"}:
                g = cand
        m2 = re.search(r"\b(\d{1,2})\b", t)
        k = int(m2.group(1)) if m2 else None
        return {"k": k, "genre": g}

    def _top_rated_query(self, k: int, genre: Optional[str]) -> List[Tuple[str, float]]:
        return self.top_rated(k=k or 5, min_ratings=50, genre=genre, decade=None)

    # ------------------------------ THEME/GENRE LOGIC ------------------------------

    def _extract_seeds(self, query: str) -> List[str]:
        query_norm = _normalize_title(query)
        matches: List[Tuple[str, float]] = []

        for title, phrases in zip(self.titles, self.search_phrases):
            best_score = 0.0
            for phrase in phrases:
                if not phrase or len(phrase) < 3:
                    continue
                if phrase in query_norm:
                    content_words = _get_content_words(phrase)
                    base_score = len(content_words)
                    if base_score == 1 and len(phrase) >= 5:
                        base_score = 1.8
                    score = base_score + len(phrase) / 100.0
                    best_score = max(best_score, score)
            if best_score > 0:
                matches.append((title, best_score))

        matches.sort(key=lambda x: -x[1])
        seeds_temp = [title for title, score in matches if score >= 1.5]

        seeds = []
        seen_bases = set()
        for title in seeds_temp:
            base = re.sub(r'\s*\(.*?\)\s*$', '', title)
            base = re.sub(r'\s*\d+[:.].*$', '', base)
            base = re.sub(r'\s*(Part|Vol\.|Volume)\s+\w+.*$', '', base, flags=re.I)
            base_norm = base.lower().strip()
            if base_norm in seen_bases:
                continue
            seen_bases.add(base_norm)
            seeds.append(title)
            if len(seeds) >= 5:
                break

        seeds_with_years = [(s, _extract_year(s) or 9999) for s in seeds]
        seeds_with_years.sort(key=lambda x: x[1])
        seeds = [s for s, _ in seeds_with_years]

        if seeds:
            seed_names = [t.rsplit('(', 1)[0].strip() for t in seeds]
            print(f"📍 Seeds: {', '.join(seed_names)}")

        return seeds

    def _analyze_seed_characteristics(self, seeds: List[str]) -> Dict:
        if not seeds:
            return {}
        characteristics = {
            'genres': set(),
            'years': [],
            'avg_year': None,
            'year_range': None,
            'is_animation': False,
            'is_horror': False,
            'is_drama': False,
        }
        for seed in seeds:
            seed_genres = set(self.genres.get(seed, []))
            characteristics['genres'].update(seed_genres)
            if seed in self.years:
                characteristics['years'].append(self.years[seed])

        genre_set = characteristics['genres']
        characteristics['is_animation'] = 'animation' in genre_set or 'children' in genre_set
        characteristics['is_horror'] = 'horror' in genre_set
        characteristics['is_drama'] = 'drama' in genre_set and not characteristics['is_animation']

        if characteristics['years']:
            years = characteristics['years']
            characteristics['avg_year'] = sum(years) / len(years)
            characteristics['year_range'] = (min(years), max(years))
        return characteristics

    def _apply_smart_filters(
        self,
        candidates: List[Tuple[str, float]],
        characteristics: Dict,
        seed_set: Set[str]
    ) -> List[Tuple[str, float]]:
        if not characteristics:
            return candidates

        filtered = []
        for title, base_score in candidates:
            if title in seed_set:
                continue

            movie_genres = set(self.genres.get(title, []))
            movie_year = self.years.get(title)
            score = base_score

            if (characteristics['is_drama'] and
                not characteristics['is_horror'] and
                not characteristics['is_animation']):
                if 'drama' not in movie_genres:
                    continue
                literary_genres = {'romance', 'war'}
                overlap = len(movie_genres & literary_genres)
                score += 0.4 * overlap
                if 'action' in movie_genres and 'romance' not in movie_genres:
                    score -= 0.2

            elif characteristics['is_animation']:
                if not any(g in movie_genres for g in ['animation', 'children', 'family', 'fantasy']):
                    continue
                if movie_year:
                    if movie_year < 2000:   score += 1.2
                    elif movie_year < 2010: score += 0.8
                    else:                   score += 0.2
                if 'musical' in movie_genres:
                    score += 0.5

            elif characteristics['is_horror']:
                has_horror_genre = 'horror' in movie_genres
                has_thriller = 'thriller' in movie_genres or 'mystery' in movie_genres
                if not (has_horror_genre or has_thriller):
                    continue
                if has_horror_genre:
                    score += 1.0
                if characteristics['avg_year'] and characteristics['avg_year'] < 1990:
                    if movie_year:
                        if not (1970 <= movie_year <= 1995):
                            continue
                        if 1970 <= movie_year <= 1989:   score += 2.0
                        elif 1990 <= movie_year <= 1995: score += 0.5
                    else:
                        continue
                else:
                    if movie_year and characteristics.get('avg_year'):
                        year_diff = abs(movie_year - characteristics['avg_year'])
                        if year_diff <= 10:
                            score += 0.5

            filtered.append((title, score))

        return filtered

    # ------------------------------------ QUERY ------------------------------------

    def query(self, text: str, topn: int = 10, genre: Optional[str] = None) -> List[Tuple[str, float]]:
        if not text:
            return []

        # exclude any seed titles mentioned
        seeds = self._extract_seeds(text)
        seed_set = set(seeds)

        # 1) Awards
        aintent = self._detect_award_intent(text)
        if aintent:
            req_n = aintent.get('req_n') or topn
            print(f"🏆 Award Query: {aintent['category']} → {req_n}")
            rows = self._award_query(aintent, seed_set, topn=req_n)
            return rows[:topn]

        # 2) Explicit Top-Rated
        tr = self._detect_top_rated(text)
        if tr:
            k = tr.get('k') or topn
            print(f"Top-Rated Query → {k} (genre={tr.get('genre')}, decade=None)")
            rows = self._top_rated_query(k=k, genre=tr.get('genre'))
            rows = [(t, s) for (t, s) in rows if t not in seed_set]
            return rows[:topn]

        # 3) Screenwriter
        wname = _detect_writer_name(text)
        if wname:
            print(f" Screenwriter Query: {wname}")
            rows = self._find_writer_movies(wname)
            rows = [(t, s) for (t, s) in rows if t not in seed_set]
            if rows:
                return rows[:topn]

        # 4) Actor
        actor_names = _detect_actor_names(text)
        if actor_names:
            printable = ", ".join(actor_names)
            print(f"Actor Query: {printable}")
            rows = self._find_actor_movies(actor_names)
            rows = [(t, s) for (t, s) in rows if t not in seed_set]
            if rows:
                return rows[:topn]

        # 5) Director
        director_name = _detect_director_query(text, set(self.directors.keys()))
        if director_name:
            print(f"🎬 Director Query: {director_name}")
            rows = self._find_director_movies(director_name)
            rows = [(t, s) for (t, s) in rows if t not in seed_set]
            if rows:
                print(f"✓ Found {len(rows)} movies by {director_name}")
                return rows[:topn]
            else:
                print(f"No movies found for director: {director_name}")

        # 6) Theme/genre/time (fallback)
        characteristics = self._analyze_seed_characteristics(seeds)
        theme: Set[str] = characteristics.get('genres', set())

        if not theme and genre:
            theme.add(genre.lower())
            print(f" No seeds, using genre: {genre}")

        if not theme:
            print("No theme detected, showing popular movies")
            candidates = [(t, self.rating.get(t, 0.0)) for t in self.titles if t not in seed_set]
            candidates.sort(key=lambda x: (-x[1], x[0]))
            return candidates[:topn]

        pattern_desc = []
        if characteristics.get('is_animation'):
            pattern_desc.append("Animation/Children")
        if characteristics.get('is_horror'):
            pattern_desc.append("Horror")
            if characteristics.get('avg_year') and characteristics['avg_year'] < 1990:
                pattern_desc.append(f"(1970s-80s era, avg year: {characteristics['avg_year']:.0f})")
        if characteristics.get('is_drama') and not characteristics.get('is_animation'):
            pattern_desc.append("Classic Drama")
        pattern_str = " + ".join(pattern_desc) if pattern_desc else "General"
        print(f"Pattern: {pattern_str}")

        scored: List[Tuple[str, float]] = []
        for title in self.titles:
            if title in seed_set:
                continue
            movie_genres = set(self.genres.get(title, []))
            overlap = len(theme & movie_genres)
            if overlap == 0:
                continue
            if genre and genre.lower() not in movie_genres:
                continue
            score = float(overlap) + 0.15 * self.rating.get(title, 3.0)
            scored.append((title, score))

        scored = self._apply_smart_filters(scored, characteristics, seed_set)
        scored.sort(key=lambda x: (-x[1], x[0]))
        return scored[:topn]

    # ----------------------- SEPARATE RATING-ONLY LOGIC -----------------------

    def top_rated(
        self,
        k: int = 5,
        min_ratings: int = 50,
        genre: Optional[str] = None,
        decade: Optional[Tuple[int, int]] = None
    ) -> List[Tuple[str, float]]:
        g = (genre or "").strip().lower() or None

        def _ok(title: str) -> bool:
            if self.rating.get(title, 0.0) <= 0:
                return False
            if self.rating_counts.get(title, 0) < min_ratings:
                return False
            if g:
                if g not in set(self.genres.get(title, [])):
                    return False
            if decade:
                y = self.years.get(title)
                if y is None or not (decade[0] <= y <= decade[1]):
                    return False
            return True

        pool = [(t, self.rating.get(t, 0.0)) for t in self.titles if _ok(t)]
        pool.sort(key=lambda x: (-x[1], -self.rating_counts.get(x[0], 0), x[0]))
        return pool[:k]


# --------------------------------- QUICK TEST ---------------------------------

if __name__ == "__main__":
    print("="*70)
    print("UNIFIED MOVIE RECOMMENDER")
    print("Awards + Writer + Actor + Director + Ratings + Theme/Genre")
    print("="*70)

    idx = MovieVectorIndex(max_movies=10000)

    tests = [
        ("Awards (Best Picture)",      "list three Best Picture Oscar winners"),
        ("Awards (GG Drama)",          "give 3 winners of Golden Globe Award for Best Motion Picture – Drama"),
        ("Writer (Kaufman)",           "films written by Charlie Kaufman"),
        ("Actor (Hanks & Ryan)",       "with Tom Hanks and Meg Ryan"),
        ("Actor (Tom Cruise)",         "I like Tom Cruise, recommend some of his films"),
        ("Director (Nolan)",           "movies directed by Christopher Nolan"),
        ("Top-rated overall",          "top 5 highest-rated movies overall"),
        ("Theme (Disney)",             "I loved The Lion King & Pocahontas — suggest similar"),
        ("Theme (Slasher)",            "like Halloween and Friday the 13th (slasher vibe)"),
    ]

    for test_name, query in tests:
        print(f"\n{'='*70}")
        print(f"{test_name}")
        print(f"{'='*70}")
        print(f"Q: {query}\n")
        results = idx.query(query, topn=5)
        if results:
            for i, (title, score) in enumerate(results, 1):
                year = idx.years.get(title, "????")
                genres = ', '.join(idx.genres.get(title, [])[:3])
                avg = idx.rating.get(title, 0.0)
                print(f"  {i}. {title:45s} ({year})  avg={avg:4.2f}  [{genres}]")
        else:
            print("   No recommendations found")
