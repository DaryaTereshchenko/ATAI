# engine.py — robust KG store + simple hybrid recommender (FAST)
from __future__ import annotations

import os
import re
import json
import hashlib
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Set, Tuple, Optional, Iterable

import rdflib as R

# ---- configuration (overridable by env) -------------------------------------
LABEL_PROPS = (
    "http://www.w3.org/2000/01/rdf-schema#label",
    "http://schema.org/name",
)
GENRE_PROPS = (
    "http://www.wikidata.org/prop/direct/P136",  # genre
)
DIRECTOR_PROPS = (
    "http://www.wikidata.org/prop/direct/P57",   # director
)
WRITER_PROPS = (
    "http://www.wikidata.org/prop/direct/P58",   # screenwriter
)
ACTOR_PROPS = (
    "http://www.wikidata.org/prop/direct/P161",  # cast member
)
DATE_PROPS = (
    "http://www.wikidata.org/prop/direct/P577",  # publication date
)
COMPANY_PROPS = (
    "http://www.wikidata.org/prop/direct/P272",  # production company
    "http://www.wikidata.org/prop/direct/P123",  # publisher
)
TAG_PROPS = (
    "http://www.wikidata.org/prop/direct/P921",  # main subject
)

# instance of (P31), film-like Qs
P31_PROP = "http://www.wikidata.org/prop/direct/P31"
FILM_QS = (
    "http://www.wikidata.org/entity/Q11424",   # film
    "http://www.wikidata.org/entity/Q24856",   # animated feature
    "http://www.wikidata.org/entity/Q229390",  # television film
    "http://www.wikidata.org/entity/Q15416",   # short film
)

def _sig(path: str) -> str:
    try:
        st = Path(path).stat()
        base = f"{Path(path).resolve()}::{st.st_size}::{int(st.st_mtime)}"
    except Exception:
        base = Path(path).name
    return hashlib.sha1(base.encode("utf-8")).hexdigest()[:12]

def _year_from_obj(obj) -> Optional[int]:
    s = str(obj)
    m = re.search(r"(\d{4})", s)
    if not m:
        return None
    try:
        y = int(m.group(1))
        if 1870 <= y <= 2100:
            return y
    except Exception:
        pass
    return None

class KGFeatureStore:
    """Lightweight KG loader with caches and fast label/person lookups."""

    def label(self, uri: str) -> str:
        return self.labels.get(uri, uri.split("/")[-1])

    def lookup_by_label(self, title: str) -> Optional[str]:
        q = self._norm(title)
        if not q:
            return None
        # exact normalized match
        for uri, norm in self.cache_labels_norm.items():
            if norm == q:
                return uri
        # token overlap (Jaccard)
        tw = set(q.split())
        best_uri, best_sim = None, 0.0
        for uri, norm in self.cache_labels_norm.items():
            uw = set(norm.split())
            inter = len(tw & uw)
            union = len(tw | uw) or 1
            sim = inter / union
            if sim > best_sim:
                best_sim, best_uri = sim, uri
        return best_uri if best_sim >= 0.7 else None

    def movies_by_person(self, role: str, person_name: str) -> List[str]:
        role = "director" if "direct" in role.lower() else ("writer" if "write" in role.lower() else role)
        name_norm = self._norm(person_name)
        uris = set()
        if name_norm in self._person_label_norm_to_uris:
            uris |= self._person_label_norm_to_uris[name_norm]
        else:
            for k, vals in self._person_label_norm_to_uris.items():
                if name_norm in k or k in name_norm:
                    uris |= vals
        movies: Set[str] = set()
        for pu in uris:
            movies |= self._movies_by_person_uri_role.get((role, pu), set())
        return sorted(movies)

    def __init__(self, path: Optional[str]):
        path = path or os.environ.get("ATAI_KG_PATH") or os.environ.get("GRAPH_FILE_PATH")
        if not path:
            raise RuntimeError("Set ATAI_KG_PATH or GRAPH_FILE_PATH to your RDF file path.")
        self._path = path
        self._sig = _sig(path)
        self._cache_dir = Path("data/.kgcache")
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._labels_path = self._cache_dir / f"labels-{self._sig}.json"
        self._features_path = self._cache_dir / f"features-{self._sig}.json"
        self._years_path = self._cache_dir / f"years-{self._sig}.json"

        self.g: Optional[R.Graph] = None
        self.movies: Set[str] = set()
        self.labels: Dict[str, str] = {}
        self.features: Dict[str, Dict[str, Set[str]]] = {}
        self.years: Dict[str, int] = {}
        self.cache_labels_norm: Dict[str, str] = {}
        self._token2uris = None  # lazy
        self._inv_feat: Dict[Tuple[str, str], Set[str]] = {}
        self._person_label_norm_to_uris: Dict[str, Set[str]] = {}
        self._movies_by_person_uri_role: Dict[Tuple[str, str], Set[str]] = {}

        if not self._load_caches():
            self.g = R.Graph()
            self.g.parse(self._path, format="nt")
            self._bootstrap()
            self._save_caches()

    def _load_caches(self) -> bool:
        try:
            if self._labels_path.exists() and self._features_path.exists():
                self.labels = json.loads(self._labels_path.read_text(encoding="utf-8"))
                feat_json = json.loads(self._features_path.read_text(encoding="utf-8"))
                self.features = {u: {k: set(v) for k, v in d.items()} for u, d in feat_json.items()}
                self.years = json.loads(self._years_path.read_text(encoding="utf-8")) if self._years_path.exists() else {}
                if self.labels:
                    self.movies = set(self.labels.keys())
                    self.cache_labels_norm = {u: self._norm(lbl) for u, lbl in self.labels.items()}
                    return True
        except Exception:
            pass
        return False

    def _save_caches(self) -> None:
        try:
            self._labels_path.write_text(json.dumps(self.labels, ensure_ascii=False), encoding="utf-8")
            feat_json = {u: {k: sorted(list(v)) for k, v in d.items()} for u, d in self.features.items()}
            self._features_path.write_text(json.dumps(feat_json, ensure_ascii=False), encoding="utf-8")
            self._years_path.write_text(json.dumps(self.years, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _bootstrap(self) -> None:
        g = self.g
        assert g is not None
        film_types = {R.URIRef(x) for x in FILM_QS}
        label_props = [R.URIRef(p) for p in LABEL_PROPS]
        genre_props = [R.URIRef(p) for p in GENRE_PROPS]
        director_props = [R.URIRef(p) for p in DIRECTOR_PROPS]
        writer_props = [R.URIRef(p) for p in WRITER_PROPS]
        actor_props = [R.URIRef(p) for p in ACTOR_PROPS]
        date_props = [R.URIRef(p) for p in DATE_PROPS]
        company_props = [R.URIRef(p) for p in COMPANY_PROPS]
        tag_props = [R.URIRef(p) for p in TAG_PROPS]
        p31 = R.URIRef(P31_PROP)

        # discover movies by P31
        movies: Set[R.term.Identifier] = set()
        for s, p, o in g.triples((None, p31, None)):
            if o in film_types:
                movies.add(s)

        # Fallback: treat subjects with P57/P58 as movies too (handles dumps lacking P31 typing)
        ALLOW_NONP31 = os.environ.get("REC_ALLOW_NONP31", "1") != "0"
        if ALLOW_NONP31:
            for p in director_props:
                for s, _p, _o in g.triples((None, p, None)):
                    movies.add(s)
            for p in writer_props:
                for s, _p, _o in g.triples((None, p, None)):
                    movies.add(s)

        # labels
        for u in movies:
            uri = str(u)
            self.movies.add(uri)
            label = None
            for lp in label_props:
                found = False
                for _, _, o in g.triples((u, lp, None)):
                    txt = str(o).strip()
                    if not txt:
                        continue
                    if getattr(o, "language", None) == "en":
                        label = txt
                        found = True
                        break
                    if label is None:
                        label = txt
                if found:
                    break
            self.labels[uri] = label or uri.split("/")[-1]

        self.cache_labels_norm = {u: self._norm(lbl) for u, lbl in self.labels.items()}

        # features
        def _add_feat(u_uri: str, key: str, obj: str):
            self.features.setdefault(u_uri, {}).setdefault(key, set()).add(obj)

        for u in movies:
            uri = str(u)
            for gp in genre_props:
                for _, _, o in g.triples((u, gp, None)):
                    _add_feat(uri, "genre", str(o))
            for p in director_props:
                for _, _, o in g.triples((u, p, None)):
                    _add_feat(uri, "director", str(o))
            for p in writer_props:
                for _, _, o in g.triples((u, p, None)):
                    _add_feat(uri, "writer", str(o))
            for p in actor_props:
                for _, _, o in g.triples((u, p, None)):
                    _add_feat(uri, "actor", str(o))
            for p in company_props:
                for _, _, o in g.triples((u, p, None)):
                    _add_feat(uri, "company", str(o))
            for p in tag_props:
                for _, _, o in g.triples((u, p, None)):
                    _add_feat(uri, "tag", str(o))
            y = None
            for p in date_props:
                for _, _, o in g.triples((u, p, None)):
                    y = _year_from_obj(o)
                    if y:
                        break
                if y:
                    break
            if y:
                self.years[uri] = y
                self.features.setdefault(uri, {}).setdefault("decade", set()).add(f"{(y//10)*10}s")

        # inverted index
        from collections import defaultdict
        self._inv_feat = defaultdict(set)
        for uri, feats in self.features.items():
            for k, vals in feats.items():
                for v in vals:
                    self._inv_feat[(k, v)].add(uri)

        # person dictionaries
        person_uris: Set[R.term.Identifier] = set()
        for role in ("director", "writer"):
            for uri, feats in self.features.items():
                for pu in feats.get(role, set()):
                    person_uris.add(R.URIRef(pu))

        def _best_label(u: R.term.Identifier) -> Optional[str]:
            best_en, fallback = None, None
            for lp in label_props:
                for _, _, o in g.triples((u, lp, None)):
                    txt = str(o).strip()
                    if not txt:
                        continue
                    if getattr(o, "language", None) == "en":
                        best_en = best_en or txt
                    fallback = fallback or txt
                if best_en:
                    break
            return best_en or fallback

        from collections import defaultdict as _dd
        self._person_label_norm_to_uris = _dd(set)
        for pu in person_uris:
            lab = _best_label(pu) or str(pu).split("/")[-1]
            self._person_label_norm_to_uris[self._norm(lab)].add(str(pu))

        self._movies_by_person_uri_role = _dd(set)
        for movie_uri, feat in self.features.items():
            for role in ("director", "writer"):
                for person_uri in feat.get(role, set()):
                    self._movies_by_person_uri_role[(role, person_uri)].add(movie_uri)

    def _norm(self, s: str) -> str:
        s = s.lower()
        s = re.sub(r"\s*\(.*?\)\s*", " ", s)
        s = re.sub(r"^(the|a|an)\s+", "", s)
        s = re.sub(r"[^a-z0-9 ]+", " ", s)
        return re.sub(r"\s+", " ", s).strip()

    def candidates_for_title(self, text: str) -> Iterable[str]:
        if self._token2uris is None:
            from collections import defaultdict
            tok = defaultdict(set)
            for uri, lbl in self.labels.items():
                for w in set(self._norm(lbl).split()):
                    if len(w) >= 3:
                        tok[w].add(uri)
            self._token2uris = {k: sorted(v) for k, v in tok.items()}
        words = [w for w in self._norm(text).split() if len(w) >= 3]
        if not words:
            return []
        acc: Set[str] = set()
        for w in words:
            acc |= set(self._token2uris.get(w, []))
        return sorted(acc)

    def neighbors_by_feature(self, seeds: Iterable[str], k: int = 200) -> List[str]:
        acc: Set[str] = set()
        for s in seeds:
            feats = self.features.get(s, {})
            for (key, vals) in feats.items():
                for v in vals:
                    acc |= self._inv_feat.get((key, v), set())
        return sorted(acc)[:k]

    def features_of(self, uri: str) -> Dict[str, Set[str]]:
        return self.features.get(uri, {})

    def all_movies(self) -> List[str]:
        return sorted(self.movies)

class FeedbackStore:
    def __init__(self, path: str = "data/feedback.json") -> None:
        self._path = path
        try:
            self._data = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception:
            self._data = {}

    def get_user_weights(self, user_id: str) -> Dict[str, float]:
        return self._data.get(user_id, {}).get("weights", {})

    def add_feedback(self, user_id: str, movie_uri: str, liked: bool) -> None:
        d = self._data.setdefault(user_id, {})
        d.setdefault("likes", set())
        d.setdefault("dislikes", set())
        if liked:
            d["likes"].add(movie_uri)
            d["dislikes"].discard(movie_uri)
        else:
            d["dislikes"].add(movie_uri)
            d["likes"].discard(movie_uri)
        try:
            out = {}
            for uid, val in self._data.items():
                out[uid] = {
                    "likes": sorted(list(val.get("likes", set()))),
                    "dislikes": sorted(list(val.get("dislikes", set()))),
                    "weights": val.get("weights", {}),
                }
            Path(self._path).write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

@dataclass
class HybridParams:
    genre_boost: float = 0.5
    company_boost: float = 0.2
    tag_boost: float = 0.2
    decade_boost: float = 0.1

class HybridRecommender:
    def __init__(self, kg: KGFeatureStore, fb: FeedbackStore,
                 avg_ratings: Optional[Dict[str, float]] = None,
                 ml_genres: Optional[Dict[str, List[str]]] = None) -> None:
        self.kg = kg
        self.fb = fb
        self.avg = avg_ratings or {}
        self.ml_genres = ml_genres or {}
        self.params = HybridParams()

    def _ml_rating(self, uri: str) -> float:
        lbl = self.kg.label(uri)
        return float(self.avg.get(lbl, 0.0))

    def recommend(self, user_id: str, seeds: Iterable[str], topn: int = 20) -> List[Tuple[str, float]]:
        seeds = [s for s in seeds if s]
        if not seeds:
            return []
        cands = self.kg.neighbors_by_feature(seeds, k=400) or self.kg.all_movies()
        seed_set = set(seeds)
        scored: List[Tuple[str, float]] = []
        seed_feats = {s: self.kg.features_of(s) for s in seeds}

        for u in cands:
            if u in seed_set:
                continue
            feats = self.kg.features_of(u)
            score = 0.0
            for s in seeds:
                sf = seed_feats[s]
                score += len(feats.get("genre", set()) & sf.get("genre", set())) * self.params.genre_boost
                score += len(feats.get("company", set()) & sf.get("company", set())) * self.params.company_boost
                score += len(feats.get("tag", set()) & sf.get("tag", set())) * self.params.tag_boost
                score += len(feats.get("decade", set()) & sf.get("decade", set())) * self.params.decade_boost
            score += 0.6 * self._ml_rating(u)
            scored.append((u, score))

        scored.sort(key=lambda x: (-x[1], self.kg.label(x[0])))
        return scored[:topn]
