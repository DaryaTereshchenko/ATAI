"""
Query Validator - keeps queries movie-related and appropriate.
"""

import re
from typing import Optional
from dataclasses import dataclass

@dataclass
class ValidationResult:
    is_valid: bool
    reason: Optional[str] = None
    category: Optional[str] = None

class QueryValidator:
    def __init__(self):
        self._setup_movie_indicators()
        self._setup_off_topic_patterns()
        self._setup_unsafe_patterns()

    def _setup_movie_indicators(self):
        self.strong_movie_keywords = {
            'movie','movies','film','films','cinema','director','directed','actor','actress',
            'screenwriter','screenplay','producer','produced','genre','genres','release','released',
            'premiere','starring','starred','acted','box office','oscar','award','nominated','rating',
            'mpaa','trailer','plot','storyline','character'
        }
        # ✅ add 'top'
        self.weak_movie_keywords = {
            'watch','watched','watching','show','entertainment','recommend','suggestion','good','best','top',
            'year','date','when','who','what','where'
        }
        self.known_movie_patterns = [
            r'\b(star wars|the godfather|pulp fiction|inception|matrix|avatar)\b',
            r'\b(lord of the rings|harry potter|marvel|batman|superman)\b',
            r'\b(titanic|forrest gump|shawshank|dark knight|fight club)\b',
        ]
        self.movie_question_patterns = [
            r'who (directed|wrote|produced|starred in|acted in)',
            r'what (genre|rating|year|date) (is|was)',
            r'when (was|did) .+ (released|made|come out)',
            r'(movies?|films?) (about|like|similar to|with|starring)',
            r'(recommend|suggest).+(movie|film)',
            r'(show|find|list).+(movie|film)',
        ]

    def _setup_off_topic_patterns(self):
        self.off_topic_patterns = {
            'mathematics': [r'\d+\s*[\+\-\*\/\^]\s*\d+', r'\bcalculate\b|\bsolve\b|\bequation\b'],
            'programming': [r'\bcode\b|\bprogram\b|\bfunction\b', r'\bpython\b|\bjava\b|\bc\+\+\b'],
            'general_knowledge': [r'\bcapital of\b|\bpopulation of\b'],
        }

    def _setup_unsafe_patterns(self):
        self.unsafe_patterns = [
            r'\b(how to|ways to) (harm|hurt|kill|attack|bomb)\b',
            r'\b(make|create|build) (weapon|explosive|bomb)\b',
            r'\b(hack|crack|steal|pirate|torrent)\b',
            r'\b(porn|sex|nude|xxx)\b',
        ]

    def validate(self, query: str) -> ValidationResult:
        if not query or not query.strip():
            return ValidationResult(False, "Query is empty", 'empty')

        q = query.lower().strip()
        # Unsafe first
        for pat in self.unsafe_patterns:
            if re.search(pat, q, re.I):
                return ValidationResult(False, "Your query contains inappropriate content.", 'unsafe')

        # Off-topic
        for _, pats in self.off_topic_patterns.items():
            for pat in pats:
                if re.search(pat, q, re.I):
                    if any(k in q for k in self.strong_movie_keywords):
                        break
                    return ValidationResult(False, "Please ask movie-related questions.", 'off_topic')

        # Movie-related?
        if any(k in q for k in self.strong_movie_keywords):
            return ValidationResult(True, category='movie_related')
        for pat in self.known_movie_patterns + self.movie_question_patterns:
            if re.search(pat, q, re.I):
                return ValidationResult(True, category='movie_related')

        weak = sum(1 for kw in self.weak_movie_keywords if kw in q)
        if weak >= 2:
            return ValidationResult(True, category='movie_related')

        return ValidationResult(False, "I'm a movie assistant. Ask about films, people, or recommendations!", 'not_movie_related')

    def get_standard_rejection_message(self) -> str:
        return (
            "🎬 **Movie Assistant**\n\n"
            "I answer questions about movies, people in film, and recommendations. "
            "Try asking for movie details, filmographies, or suggestions!"
        )
