"""
Robust rule-based query classifier for movie queries.
Fixes:
  • 'movies directed by X' and 'X's best movies' → recommendation
  • 'like'/'similar to' phrasing → recommendation
"""

import re
from typing import Dict, List, Optional
from enum import Enum
from dataclasses import dataclass


class QuestionType(str, Enum):
    FACTUAL = "factual"
    MULTIMEDIA = "multimedia"
    RECOMMENDATION = "recommendation"


@dataclass
class ClassificationResult:
    question_type: QuestionType
    confidence: float
    matched_patterns: List[str]
    extracted_info: Dict[str, any]


class RobustQueryClassifier:
    def __init__(self):
        self._setup_patterns()
        self._setup_keywords()
        self._setup_linguistic_features()

    def _setup_patterns(self):
        self.factual_patterns = [
            (r'\bwho\s+(directed|made|wrote|produced|acted|starred)\b', 0.95),
            (r'\bwhat\s+(genre|rating|release\s+date|country)\b', 0.95),
            (r'\bwhen\s+(was|did)\s+.+\s+(released|made|produced|come\s+out)\b', 0.95),
            (r'\bwhere\s+was\s+.+\s+(filmed|made|produced)\b', 0.90),
        ]

        # ✅ Recommendation patterns (expanded)
        self.recommendation_patterns = [
            (r'\b(recommend|suggest)\b', 0.95),
            (r'\bwhat\s+should\s+i\s+watch\b', 0.95),
            (r'\b(any|some)\s+good\s+(movies?|films?)\b', 0.90),
            (r'\btop\s+\d{1,2}\b', 0.90),
            (r'\b(best|highest(?:\s*rated)?)\s+\d{1,2}\b', 0.90),
            (r'\b(best|top|highest(?:\s*rated)?)\s+(movies?|films?)\b', 0.85),
            # NEW: similarity phrasing
            (r'\b(like|similar\s+to)\b', 0.90),
            # NEW: director phrasing
            (r'\b(movies|films)\s+directed\s+by\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b', 0.95),
            (r"[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\s*'s\s+(?:best\s+)?(?:movies|films)\b", 0.95),
            (r'\b(movies|films)\s+by\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b', 0.95),
        ]

    def _setup_keywords(self):
        self.factual_keywords = {
            'high_confidence': {'genre','rating','release','year','date','country','award'},
            'medium_confidence': {'who','what','when','where','movie','film','find','search','list','show','tell','directed'}
        }
        self.multimedia_keywords = {'high_confidence': {'picture','image','photo','poster','visual','display','see','view','show'}}
        self.recommendation_keywords = {'high_confidence': {'recommend','suggest','should','watch','good','best','top','highest','rated','like','similar'}}

    def _setup_linguistic_features(self):
        self.modal_verbs = {'should','could','would','might'}
        self.question_words = {'who','what','when','where','which','why','how'}
        self.imperatives = {'tell','show','give','find','list','get','display'}

    def classify(self, query: str) -> ClassificationResult:
        q = (query or "").strip()

        # 1) Strict patterns first
        p = self._classify_by_patterns(q)
        if p: return p

        # 2) Keywords
        k = self._classify_by_keywords(q.lower())
        if k and k.confidence > 0.75: return k

        # 3) Linguistics
        l = self._classify_by_linguistics(q.lower())
        if l: return l

        return ClassificationResult(QuestionType.FACTUAL, 0.6, ['default_factual'], {'reason':'default'})

    def _classify_by_patterns(self, q: str) -> Optional[ClassificationResult]:
        for pat, conf in self.recommendation_patterns:
            if re.search(pat, q):
                return ClassificationResult(QuestionType.RECOMMENDATION, conf, [pat], {'pattern':'recommendation'})
        for pat, conf in self.factual_patterns:
            if re.search(pat, q, re.I):
                return ClassificationResult(QuestionType.FACTUAL, conf, [pat], {'pattern':'factual'})
        return None

    def _classify_by_keywords(self, q: str) -> Optional[ClassificationResult]:
        words = set(q.split())
        scores = {QuestionType.FACTUAL:0.0, QuestionType.MULTIMEDIA:0.0, QuestionType.RECOMMENDATION:0.0}
        for w in words:
            if w in self.factual_keywords['high_confidence']: scores[QuestionType.FACTUAL]+=0.15
            elif w in self.factual_keywords['medium_confidence']: scores[QuestionType.FACTUAL]+=0.06
            if w in self.multimedia_keywords['high_confidence']: scores[QuestionType.MULTIMEDIA]+=0.2
            if w in self.recommendation_keywords['high_confidence']: scores[QuestionType.RECOMMENDATION]+=0.22
        max_type = max(scores, key=scores.get); max_score = scores[max_type]
        if max_score > 0.35:
            return ClassificationResult(max_type, min(0.9, max_score), ['keyword_analysis'], {'scores':scores})
        return None

    def _classify_by_linguistics(self, q: str) -> Optional[ClassificationResult]:
        words = q.split()
        if any(w in self.modal_verbs for w in words) and 'watch' in words:
            return ClassificationResult(QuestionType.RECOMMENDATION, 0.75, ['modal_watch'], {})
        if words and words[0] in self.question_words:
            return ClassificationResult(QuestionType.FACTUAL, 0.7, ['question_word'], {})
        if words and words[0] in self.imperatives:
            return ClassificationResult(QuestionType.FACTUAL, 0.7, ['imperative'], {})
        return None
