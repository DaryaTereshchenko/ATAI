"""
LangGraph-style workflow for query processing.
Routes recommendation queries to the recommender.
"""

import sys
import os
from typing import TypedDict, Optional, List
from enum import Enum
from dataclasses import dataclass

# Add project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
sys.path.insert(0, project_root)

from src.main.answer_formatter import AnswerFormatter  # keep as-is


class ProcessingMethod(str, Enum):
    SPARQL = "sparql"
    EMBEDDING = "embedding"
    HYBRID = "hybrid"
    RECOMMENDER = "recommender"
    FAILED = "failed"


class WorkflowState(TypedDict):
    raw_query: str
    is_valid: bool
    validation_message: Optional[str]
    detected_threats: List[str]
    query_type: Optional[str]
    processing_method: Optional[ProcessingMethod]
    routing_reason: Optional[str]
    generated_sparql: Optional[str]
    sparql_confidence: float
    sparql_explanation: Optional[str]
    raw_result: Optional[str]
    formatted_response: Optional[str]
    error: Optional[str]
    current_node: str


class InputValidator:
    """Light, safe normalization + guardrails."""
    MAX_QUERY_LENGTH = 1000
    MIN_QUERY_LENGTH = 2

    MALICIOUS_PATTERNS = [
        r"(?i)(union\s+select|drop\s+table|insert\s+into|delete\s+from)",
        r"(?i)(<script|javascript:|onerror=|onclick=)",
        r"(?i)(;\s*rm\s+-rf|&&\s*cat\s+|`.*`|\$\(.*\))",
        r"(\.\./|\.\.\\|%2e%2e)",
        r"(?i)(;\s*drop|;\s*insert|;\s*delete|;\s*clear)",
        r"[<>{}|\[\]]{5,}",
    ]
    SUSPICIOUS_CHARS = ["\x00", "\r\n\r\n", "<?php", "<%"]

    @classmethod
    def preprocess_query(cls, s: str) -> str:
        import re
        if not s: return ""
        s = s.strip()
        trans = {ord("“"): '"', ord("”"): '"', ord("‘"): "'", ord("’"): "'", ord("—"): "-", ord("–"): "-", 0xA0: 32}
        s = s.translate(trans)
        s = re.sub(r"\s+", " ", s).strip()
        return s

    @classmethod
    def validate(cls, query: str) -> dict:
        import re
        cleaned = cls.preprocess_query(query)
        if not cleaned:
            return {"is_valid": False, "message": "Query cannot be empty.", "threats": ["empty_input"], "cleaned_query": cleaned}
        if len(cleaned) > cls.MAX_QUERY_LENGTH:
            return {"is_valid": False, "message": f"Query is too long (max {cls.MAX_QUERY_LENGTH}).", "threats": ["excessive_length"], "cleaned_query": cleaned}
        if len(cleaned) < cls.MIN_QUERY_LENGTH:
            return {"is_valid": False, "message": "Query is too short.", "threats": ["insufficient_length"], "cleaned_query": cleaned}
        threats = []
        for pat in cls.MALICIOUS_PATTERNS:
            if re.search(pat, query):
                threats.append(f"malicious:{pat}")
        for seq in cls.SUSPICIOUS_CHARS:
            if seq in query:
                threats.append(f"suspicious:{seq}")
        if threats:
            return {"is_valid": False, "message": "Query contains potentially malicious content.", "threats": threats, "cleaned_query": cleaned}
        return {"is_valid": True, "message": "OK", "threats": [], "cleaned_query": cleaned}


class QueryWorkflow:
    def __init__(self, orchestrator):
        self.orchestrator = orchestrator
        self.validator = InputValidator()
        self.formatter = AnswerFormatter()

    def validate_input(self, state: WorkflowState) -> WorkflowState:
        print(f"\n[NODE validate_input] → {state['raw_query'][:80]}...")
        v = self.validator.validate(state["raw_query"])
        state["is_valid"] = v["is_valid"]; state["validation_message"] = v["message"]; state["detected_threats"] = v["threats"]
        if v.get("cleaned_query"): state["raw_query"] = v["cleaned_query"]
        state["current_node"] = "validate_input"
        if not v["is_valid"]:
            state["processing_method"] = ProcessingMethod.FAILED
            state["error"] = v["message"]
        return state

    def classify_query(self, state: WorkflowState) -> WorkflowState:
        print("[NODE classify_query]")
        try:
            result = self.orchestrator.classify_query(state["raw_query"])
            state["query_type"] = result.question_type.value
            print(f"  type={state['query_type']} conf={result.confidence:.2f}")
        except Exception as e:
            state["query_type"] = "unknown"
            state["error"] = f"classification failed: {e}"
        state["current_node"] = "classify_query"
        return state

    def decide_processing_method(self, state: WorkflowState) -> WorkflowState:
        print("[NODE decide_processing_method]")
        qt = state.get("query_type", "hybrid")
        if qt == "factual":
            state["processing_method"] = ProcessingMethod.SPARQL
        elif qt == "recommendation":
            state["processing_method"] = ProcessingMethod.RECOMMENDER
        else:
            state["processing_method"] = ProcessingMethod.HYBRID
        state["current_node"] = "decide_processing_method"
        print(f"  → {state['processing_method'].value}")
        return state

    def process_with_recommender(self, state: WorkflowState) -> WorkflowState:
        print("[NODE process_with_recommender]")
        try:
            out = self.orchestrator._process_recommendation(state["raw_query"])
            state["raw_result"] = out
            state["formatted_response"] = out
        except Exception as e:
            state["error"] = f"recommender error: {e}"
        state["current_node"] = "process_with_recommender"
        return state

    # (Placeholders for factual/embedding/hybrid if you use them)
    def process_with_factual(self, state: WorkflowState) -> WorkflowState:
        state["error"] = "Factual pipeline not configured in this build."
        state["current_node"] = "process_with_factual"
        return state

    def process_with_embeddings(self, state: WorkflowState) -> WorkflowState:
        state["error"] = "Embeddings pipeline not configured in this build."
        state["current_node"] = "process_with_embeddings"
        return state

    def process_with_both(self, state: WorkflowState) -> WorkflowState:
        state["error"] = "Hybrid pipeline not configured in this build."
        state["current_node"] = "process_with_both"
        return state

    def format_response(self, state: WorkflowState) -> WorkflowState:
        print("[NODE format_response]")
        if state.get("error"):
            state["formatted_response"] = self.formatter.format_error(state["error"])
        elif not state.get("formatted_response"):
            state["formatted_response"] = state.get("raw_result") or "No result."
        state["current_node"] = "format_response"
        return state

    def run(self, query: str) -> str:
        print("\n================ WORKFLOW START ================\n")
        state: WorkflowState = {
            'raw_query': query, 'is_valid': False, 'validation_message': None, 'detected_threats': [],
            'query_type': None, 'processing_method': None, 'routing_reason': None, 'generated_sparql': None,
            'sparql_confidence': 0.0, 'sparql_explanation': None, 'raw_result': None,
            'formatted_response': None, 'error': None, 'current_node': 'start'
        }
        state = self.validate_input(state)
        if not state['is_valid']: return self.format_response(state)['formatted_response']
        state = self.classify_query(state)
        state = self.decide_processing_method(state)

        if state['processing_method'] == ProcessingMethod.RECOMMENDER:
            state = self.process_with_recommender(state)
        elif state['processing_method'] == ProcessingMethod.SPARQL:
            state = self.process_with_factual(state)
        elif state['processing_method'] == ProcessingMethod.EMBEDDING:
            state = self.process_with_embeddings(state)
        else:
            state = self.process_with_both(state)

        state = self.format_response(state)
        print("\n================ WORKFLOW END ==================\n")
        return state['formatted_response']
