BOT_USERNAME='BeigeCrackingEgg'
BOT_PASSWORD='Vb2Xv8iY$ky2024!'
GRAPH_FILE_PATH='data/graph.nt'
EMBEDDING_QUERY_MODEL='sentence-transformers/all-MiniLM-L6-v2'
EMBEDDING_ALIGNMENT_MATRIX_PATH='data/embedding_alignment_matrix.npy'
NL2SPARQL_MODEL='google/flan-t5-small'

import os
import pathlib

# ---------- Project paths ----------
# This file lives at: ATAI-main/src/config.py
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

print(f"🗂️  Project root detected: {PROJECT_ROOT}")

# Local graph (N-Triples)
_default_graph = PROJECT_ROOT / "data" / "graph.nt"

GRAPH_FILE_PATH = os.getenv("GRAPH_FILE_PATH", str(_default_graph.resolve()))
if os.path.exists(GRAPH_FILE_PATH):
    size_mb = os.path.getsize(GRAPH_FILE_PATH) / (1024 * 1024)
    print(f"✅ Found graph.nt ({size_mb:.1f} MB) at: {GRAPH_FILE_PATH}")
else:
    print(f"❌ ERROR: graph.nt NOT FOUND at: {GRAPH_FILE_PATH}")
    print(f"   Expected location: {_default_graph}")
    print(f"   Set GRAPH_FILE_PATH env var to the correct path")

# ---------- Speakeasy / Bot credentials ----------
SPEAKEASY_HOST = os.getenv("SPEAKEASY_HOST", "https://speakeasy.ifi.uzh.ch")
BOT_USERNAME   = os.getenv("SPEAKEASY_USERNAME", "demo-bot")
BOT_PASSWORD   = os.getenv("SPEAKEASY_PASSWORD", "demo-pass")

# ---------- Global LLM Settings ----------
# Options: "gguf" | "ollama" | "none"
LLM_TYPE = os.getenv("LLM_TYPE", "ollama")
LLM_MODEL = os.getenv("LLM_MODEL", "mistral")

DEFAULT_GGUF = PROJECT_ROOT / "models" / "model.gguf"
LLM_MODEL_PATH = os.getenv("LLM_MODEL_PATH", str(DEFAULT_GGUF))

if LLM_TYPE == "gguf":
    if not os.path.exists(LLM_MODEL_PATH):
        print(f"⚠️  Model file not found: {LLM_MODEL_PATH}")
        print(f"   Expected: {DEFAULT_GGUF}")
    else:
        print(f"✅ Found GGUF model at: {LLM_MODEL_PATH}")

LLM_TEMPERATURE    = float(os.getenv("LLM_TEMPERATURE", "0.1"))
LLM_MAX_TOKENS     = int(os.getenv("LLM_MAX_TOKENS", "256"))
LLM_CONTEXT_LENGTH = int(os.getenv("LLM_CONTEXT_LENGTH", "4096"))

# Use LLM for classification?
USE_LLM_CLASSIFICATION = os.getenv("USE_LLM_CLASSIFICATION", "false").lower() in ("1","true","yes")

# Optional: language guard in label lookups
ADD_LABEL_LANG_FILTER = os.getenv("ADD_LABEL_LANG_FILTER", "false").lower() in ("1","true","yes")
LABEL_LANG = os.getenv("LABEL_LANG", "en")

# ---------- NL→SPARQL settings ----------
NL2SPARQL_METHOD = os.getenv("NL2SPARQL_METHOD", "rule-based")
NL2SPARQL_PROVIDER = os.getenv("NL2SPARQL_PROVIDER", "llamacpp")
NL2SPARQL_LLM_MODEL_PATH = os.getenv("NL2SPARQL_LLM_MODEL_PATH", os.getenv("NL2SPARQL_MODEL_PATH", LLM_MODEL_PATH))
NL2SPARQL_LLM_MODEL      = os.getenv("NL2SPARQL_LLM_MODEL", os.getenv("NL2SPARQL_MODEL", LLM_MODEL))

NL2SPARQL_TEMPERATURE        = float(os.getenv("NL2SPARQL_TEMPERATURE",        str(LLM_TEMPERATURE)))
NL2SPARQL_LLM_TEMPERATURE    = float(os.getenv("NL2SPARQL_LLM_TEMPERATURE",    str(NL2SPARQL_TEMPERATURE)))
NL2SPARQL_MAX_TOKENS         = int(os.getenv( "NL2SPARQL_MAX_TOKENS",          str(LLM_MAX_TOKENS)))
NL2SPARQL_LLM_MAX_TOKENS     = int(os.getenv( "NL2SPARQL_LLM_MAX_TOKENS",      str(NL2SPARQL_MAX_TOKENS)))
NL2SPARQL_CONTEXT_LEN        = int(os.getenv( "NL2SPARQL_CONTEXT_LEN",         str(LLM_CONTEXT_LENGTH)))
NL2SPARQL_LLM_CONTEXT_LENGTH = int(os.getenv( "NL2SPARQL_LLM_CONTEXT_LEN",     str(NL2SPARQL_CONTEXT_LEN)))






# Question Type Classifier (factual/multimedia/recommendation/out-of-scope)
TRANSFORMER_MODEL_PATH = "/files/Project Submission 2/src/main/classifier_fine_tuning/models/query_classifier"
# SPARQL Pattern Classifier (forward_director/reverse_cast_member/etc.)
SPARQL_CLASSIFIER_MODEL_PATH = "/files/Project Submission 2/src/main/classifier_fine_tuning/models/sparql_classifier"

# ==================== Label Language Filtering ====================

# Add language filter to SPARQL queries (optional)
ADD_LABEL_LANG_FILTER = False  # Set to True to filter labels by language
LABEL_LANG = "en"  # Language code for label filtering

# ==================== Workflow Configuration ====================

# Enable workflow-based processing (recommended)
USE_WORKFLOW = True

# ==================== Embedding Configuration ====================

# Enable embedding-based query processing (TransE + Sentence Transformers)
USE_EMBEDDINGS = True

# Directory containing TransE embeddings
EMBEDDINGS_DIR = "/space_mounts/atai-hs25/dataset/embeddings"

EMBEDDING_QUERY_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# Path to trained alignment matrix (optional, None = use simple aligner)
EMBEDDING_ALIGNMENT_MATRIX_PATH = None  # No trained matrix yet

# Embedding search parameters
EMBEDDING_TOP_K = 10  # Number of results to return
EMBEDDING_MIN_SIMILARITY = 0.8  # Increase threshold for quoted queries (was 0.0)

# Entity extraction parameters
ENTITY_EXTRACTION_THRESHOLD = 85  # Fuzzy match threshold for non-quoted text
ENTITY_EXTRACTION_QUOTED_THRESHOLD = 90  # Higher threshold for quoted text
