"""Minimal stub of rdflib to allow engine.py to run without external dependency.

This stub implements only the small subset of rdflib functionality required by
the recommendation engine.  It supports parsing a simple N-Triples (.nt) file
into an in-memory graph and provides rudimentary `URIRef`, `Literal` and
`Graph` classes.  The goal is not to be a full RDF library but to supply
enough functionality for the existing code to extract labels and basic
relations from a knowledge graph.  If the real `rdflib` package is
available, that should be preferred, but in restricted environments this
lightweight implementation suffices.

Limitations:
  * Only N-Triples format is supported by `Graph.parse`.
  * Datatype URIs on literals are ignored; only language tags are parsed.
  * No support for namespaces, BNodes, or advanced RDF features.
  * `URIRef` and `Literal` instances behave like strings for hashing and
    equality, but `Literal` exposes a `.language` attribute when present.
"""

from __future__ import annotations

import re
from typing import Iterable, Iterator, List, Optional, Tuple, Union

__all__ = ["Graph", "URIRef", "Literal", "term"]


class URIRef(str):
    """Represents an RDF URI reference.  In this stub it behaves like a
    string but is a distinct type to aid pattern matching.
    """

    def __new__(cls, value: str) -> "URIRef":
        return str.__new__(cls, value)


class Literal(str):
    """Represents an RDF literal with an optional language tag.

    Inherits from `str` so that string operations behave normally.  A
    language tag can be attached via the `language` attribute.  Datatype
    information is ignored in this stub.
    """

    def __new__(cls, value: str, language: Optional[str] = None) -> "Literal":
        obj = str.__new__(cls, value)
        obj.language = language
        return obj


class term:
    """Namespace providing minimal type annotations for rdflib.term.Identifier.

    This stub defines `Identifier` as an alias of `URIRef`, since our
    implementation does not distinguish between different RDF terms for
    hashing or equality.
    """

    Identifier = URIRef  # type: ignore


class Graph:
    """Simple in-memory graph for N-Triples data.

    The graph stores triples as a list of (subject, predicate, object)
    tuples.  `parse` can load a file containing N-Triples, and
    `triples` yields triples matching a pattern with optional wildcards.
    """

    def __init__(self) -> None:
        self._triples: List[Tuple[Union[URIRef, Literal], Union[URIRef, Literal], Union[URIRef, Literal]]] = []

    def parse(self, path: str, format: Optional[str] = None) -> "Graph":
        """Load triples from a file in N-Triples format.

        Each line should follow the pattern:
          <subject> <predicate> <object> .
        Objects can be URIs (enclosed in <>) or literals in quotes with
        optional language tags (e.g., "foo"@en) or datatype annotations
        (ignored).  Lines that do not conform to this pattern are skipped.
        """
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                # Basic regex for N-Triples: <s> <p> <o> .
                m = re.match(r"^<([^>]+)>\s+<([^>]+)>\s+(.*?)\s*\.\s*$", line)
                if not m:
                    continue
                s_uri, p_uri, o_part = m.groups()
                subj = URIRef(s_uri)
                pred = URIRef(p_uri)
                obj: Union[URIRef, Literal]
                if o_part.startswith("<") and o_part.endswith(">"):
                    # object is a URI
                    obj_uri = o_part[1:-1]
                    obj = URIRef(obj_uri)
                else:
                    # literal: "value"@lang or "value"^^<type>
                    literal_match = re.match(r'"(.*?)"(?:@([a-zA-Z\-]+))?(?:\^\^<[^>]+>)?$', o_part)
                    if literal_match:
                        val, lang = literal_match.groups()
                        obj = Literal(val, language=lang)
                    else:
                        # Fallback: treat as plain string without lang
                        obj = Literal(o_part.strip('"'))
                self._triples.append((subj, pred, obj))
        return self

    def triples(self, pattern: Tuple[Optional[Union[URIRef, Literal]], Optional[Union[URIRef, Literal]], Optional[Union[URIRef, Literal]]]) -> Iterator[Tuple[Union[URIRef, Literal], Union[URIRef, Literal], Union[URIRef, Literal]]]:
        """Yield triples matching the given (s, p, o) pattern.

        Any element of the pattern may be `None`, which matches any
        corresponding term.  Matching is based on equality of the
        underlying value.  Literal language tags are not considered in
        comparisons.
        """
        s_pat, p_pat, o_pat = pattern
        for s, p, o in self._triples:
            if s_pat is not None and s != s_pat:
                continue
            if p_pat is not None and p != p_pat:
                continue
            if o_pat is not None and o != o_pat:
                continue
            yield (s, p, o)
